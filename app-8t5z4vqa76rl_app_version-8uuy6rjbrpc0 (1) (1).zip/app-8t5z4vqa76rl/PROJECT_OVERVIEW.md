# AI-Powered Calorie Tracking Device for Canteen Menu

A comprehensive health monitoring application designed for college students to track their daily calorie intake through intelligent AI-powered food scanning. The application provides personalized fitness recommendations and exercise suggestions based on user profiles and fitness goals.

## 🌟 Features

### Authentication & Onboarding
- **User Registration & Login**: Secure username/password authentication
- **First-Time Profile Setup**: Collect gender, age, height, weight, and activity level
- **Fitness Goal Selection**: Choose from weight loss, fat loss, muscle gain, or maintain fitness
- **Automatic Calorie Target Calculation**: Based on BMR, activity level, and fitness goals

### AI Food Scanner (Core Feature)
- **Camera Integration**: Capture food images directly or upload from device
- **AI-Powered Analysis**: Uses Google Gemini 2.5 Flash for accurate food recognition
- **Comprehensive Nutrition Data**: 
  - Food name identification
  - Portion size estimation
  - Calorie count
  - Macronutrients (protein, carbohydrates, fats)
  - AI confidence score
- **Automatic Image Compression**: Optimizes images to under 1MB with WebP format
- **Real-time Daily Log Updates**: Automatically updates your daily calorie intake

### Food Database
- **45 Healthy Food Items**: Pre-loaded with nutritious meal options including Indian and South Indian cuisine
- **Beautiful Food Images**: High-quality images for each food item
- **Complete Nutrition Information**: Calories, protein, carbs, fats, and serving sizes
- **Category Filtering**: Browse by Breakfast, Main Course, Salad, Soup, or Snack
- **Indian Food Options**: 15 authentic Indian dishes including Biryani, Dal, Paneer, Dosa, and more
- **South Indian Breakfast**: 5 traditional South Indian items (Medu Vada, Uttapam, Pongal, Appam, Pesarattu)
- **Nutritious Superfoods**: Quinoa bowls, chia seed pudding, Greek yogurt, protein smoothies, and more
- **Search Functionality**: Quickly find specific foods
- **Nutrition Tips**: Helpful guidance for balanced eating
- **Reference Guide**: Use as inspiration for healthy meal choices

### Dashboard
- **Beautiful Stat Widgets**: 4 colorful cards showing calories consumed, burned, net, and remaining
- **Calories Burned Tracking**: Real-time display of exercise and steps calories burned today
- **Net Calorie Calculation**: Automatic calculation of consumed minus burned calories (including steps)
- **Daily Calorie Summary**: View calories consumed vs. target
- **Remaining Calories**: Track how many calories you have left for the day
- **Progress Visualization**: Interactive progress bar with percentage display showing calorie consumption
- **Macronutrient Breakdown**: See your daily protein, carbs, and fats intake with color-coded progress bars
- **Fitness Goal Display**: Visual representation of your current fitness goal with icon
- **Quick Action Buttons**: Fast access to Scan Food, Log Exercise, and View History
- **Quick Scanner Access**: One-click access to food scanner
- **Personalized Exercise Recommendations**: Based on your fitness goal

### History & Records
- **Food Scan History**: View all your scanned meals with images and nutrition data
- **Daily Logs**: Track your calorie intake over time
- **Weekly Overview**: See your nutrition trends for the past 7 days
- **Bar Charts**: Visual representation of daily calorie intake, calories burned (exercises + steps), and net calories
- **Calories Burned Tracking**: View exercise and steps calories burned for each day in charts and logs
- **Net Calorie Display**: See consumed minus burned calories for accurate tracking
- **Weekly Summary**: Total consumed, total burned (exercises + steps), net calories, and days tracked
- **Detailed Nutrition Info**: Access complete macronutrient data for each meal
- **Exercise Integration**: Daily logs show both food intake and exercise burn including steps

### Exercise Recommendations & Logging
- **Step Tracking**: Log daily steps with automatic calorie burn calculation
- **Steps Widget**: Beautiful card showing today's steps and calories burned from walking
- **Dual Logging Interface**: Separate buttons for logging exercises and steps
- **Exercise Logging Interface**: Log exercises with duration, date, and notes
- **Calories Burned Calculation**: Automatic calculation based on exercise type and duration
- **Today's Exercise Stats**: Beautiful widgets showing calories burned, total duration, workouts completed, and steps
- **Exercise History**: View all logged exercises with detailed information
- **Delete Exercise Logs**: Remove incorrect or unwanted exercise entries
- **Curated Exercise Database**: 10+ exercises across different categories
- **Category Filtering**: Browse by Cardio, Strength, or Flexibility
- **Calorie Burn Estimates**: See calories burned per 30 minutes for each exercise
- **Personalized Duration**: Recommended exercise duration based on your fitness goal
- **Difficulty Levels**: Easy, Medium, and Hard exercises
- **Exercise Cards**: Beautiful cards with exercise details, category badges, and calorie information
- **Two-Tab Interface**: Switch between exercise recommendations and your exercise logs

## 🎨 Design System

### Color Scheme
- **Primary (Green)**: Health and wellness theme - `hsl(142, 76%, 36%)`
- **Secondary (Blue)**: Trust and professionalism - `hsl(210, 100%, 50%)`
- **Accent**: Light green for highlights - `hsl(142, 76%, 92%)`
- **Success**: Green for positive actions
- **Warning**: Yellow for cautions
- **Destructive**: Red for errors

### Layout
- **Desktop-First Design**: Optimized for desktop with mobile adaptation
- **Responsive Sidebar**: Fixed sidebar on desktop, hamburger menu on mobile
- **Clean Card-Based UI**: Modern card layouts for content organization
- **Smooth Animations**: Fade-in and slide-in effects for better UX

## 🗄️ Database Schema

### Tables
1. **profiles**: User authentication data (synced from auth.users)
2. **user_profiles**: Health data (gender, age, height, weight, activity level, fitness goal)
3. **food_scans**: AI-analyzed food scan records with nutrition data
4. **daily_logs**: Aggregated daily calorie and macronutrient totals
5. **exercise_recommendations**: Pre-populated exercise database (10 exercises)
6. **exercise_logs**: User exercise tracking with duration and calories burned
7. **steps_logs**: Daily step tracking with automatic calorie calculation (0.04 cal/step)
8. **food_database**: Pre-loaded healthy food items with images and nutrition (45 foods including 15 Indian dishes and 5 South Indian breakfast items)

### Storage
- **Food Images Bucket**: Stores uploaded food images with public access

## 🔐 Security

### Row Level Security (RLS)
- Users can only view and edit their own data
- First registered user automatically becomes admin
- Admin has full access to all data
- Public read access for exercise recommendations

### Authentication
- Username + password authentication (simulated email with @miaoda.com)
- No email verification required for quick onboarding
- Secure password requirements (minimum 6 characters)
- Username validation (letters, numbers, underscores only)

## 🤖 AI Integration

### Gemini 2.5 Flash API
- **Edge Function**: `analyze-food` deployed on Supabase
- **Multimodal Analysis**: Processes both image and text prompts
- **Streaming Response**: Handles SSE (Server-Sent Events) for real-time results
- **Structured Output**: Returns JSON with food name, calories, macros, and confidence

### Image Processing
- **Automatic Compression**: Reduces images to under 1MB
- **Format Conversion**: Converts to WebP for optimal storage
- **Resolution Optimization**: Maintains aspect ratio while limiting to 1080p
- **Quality Control**: 0.8 quality setting for balance between size and clarity

## 📱 User Flow

### First-Time User
1. Register with username and password
2. Complete profile setup (gender, age, height, weight, activity level)
3. Select fitness goal (weight loss, fat loss, muscle gain, maintain)
4. Redirected to dashboard with personalized calorie target

### Regular User
1. Login with credentials
2. View dashboard with today's progress
3. Scan food items throughout the day
4. Track progress in real-time
5. View history and exercise recommendations
6. Logout when done

## 🛠️ Technical Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for fast development and building
- **React Router** for navigation
- **shadcn/ui** for UI components
- **Tailwind CSS** for styling
- **Lucide React** for icons

### Backend
- **Supabase** for database and authentication
- **PostgreSQL** for data storage
- **Supabase Storage** for image hosting
- **Supabase Edge Functions** for serverless AI integration

### AI & APIs
- **Google Gemini 2.5 Flash** for food recognition
- **Gemini Vision API** for image understanding
- **SSE (Server-Sent Events)** for streaming responses

## 📊 Calorie Calculation

### BMR (Basal Metabolic Rate)
- **Male**: 10 × weight(kg) + 6.25 × height(cm) - 5 × age + 5
- **Female**: 10 × weight(kg) + 6.25 × height(cm) - 5 × age - 161

### TDEE (Total Daily Energy Expenditure)
- BMR × Activity Level Multiplier:
  - Sedentary: 1.2
  - Lightly Active: 1.375
  - Moderately Active: 1.55
  - Very Active: 1.725
  - Extremely Active: 1.9

### Goal Adjustments
- **Weight Loss**: TDEE - 500 kcal
- **Fat Loss**: TDEE - 300 kcal
- **Muscle Gain**: TDEE + 300 kcal
- **Maintain Fitness**: TDEE

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ installed
- pnpm package manager
- Modern web browser

### Installation
```bash
# Install dependencies
pnpm install

# Start development server
pnpm dev
```

### First User Setup
1. The first user to register will automatically become an admin
2. Complete the onboarding flow to set up your profile
3. Start scanning food and tracking your calories!

## 📝 Usage Tips

### For Best AI Recognition Results
- Take clear, well-lit photos of your food
- Capture the entire plate or food item
- Avoid blurry or dark images
- Include common food items for better accuracy

### For Accurate Tracking
- Scan all meals and snacks throughout the day
- Review AI results and adjust if needed
- Check your dashboard regularly to stay on track
- Follow exercise recommendations for your goal

### For Optimal Results
- Be consistent with daily tracking
- Set realistic fitness goals
- Combine calorie tracking with regular exercise
- Stay hydrated and get adequate sleep

## 🎓 Academic Value

### Innovation Highlights
- **AI-Driven Solution**: Addresses real-world problem of unhealthy eating in college canteens
- **Practical Application**: Demonstrates integration of AI in health technology
- **User-Centric Design**: Easy to use for non-technical college students
- **Scalable Architecture**: Can be extended with more features

### Technical Demonstrations
- Multimodal AI integration (image + text)
- Real-time data processing and updates
- Secure authentication and data privacy
- Responsive web design principles
- RESTful API integration
- Database design and optimization

## 📄 License

Copyright © 2026 CalorieTracker. All rights reserved.

## 🙏 Acknowledgments

- Google Gemini API for AI-powered food recognition
- Supabase for backend infrastructure
- shadcn/ui for beautiful UI components
- The open-source community for amazing tools and libraries
