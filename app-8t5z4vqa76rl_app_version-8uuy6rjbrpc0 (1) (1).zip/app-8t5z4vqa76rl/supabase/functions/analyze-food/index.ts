import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface FoodAnalysisResult {
  foodName: string;
  calories: number;
  protein: number;
  carbohydrates: number;
  fats: number;
  portionSize: string;
  confidence: number;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    const { data: { user } } = await supabaseClient.auth.getUser();
    if (!user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { imageData, mimeType } = await req.json();

    if (!imageData || !mimeType) {
      return new Response(
        JSON.stringify({ error: 'Missing imageData or mimeType' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const base64Data = imageData.replace(/^data:image\/\w+;base64,/, '');

    const prompt = `Analyze this food image and provide detailed nutritional information. 
    
    Please identify:
    1. The name of the food item(s)
    2. Estimated portion size (e.g., "1 plate", "200g", "1 cup")
    3. Total calories
    4. Protein content in grams
    5. Carbohydrates content in grams
    6. Fats content in grams
    7. Your confidence level in this analysis (0-1)
    
    Respond ONLY with a valid JSON object in this exact format:
    {
      "foodName": "string",
      "portionSize": "string",
      "calories": number,
      "protein": number,
      "carbohydrates": number,
      "fats": number,
      "confidence": number
    }
    
    Do not include any additional text or explanation, only the JSON object.`;

    const geminiResponse = await fetch(
      'https://api-integrations.appmedo.com/app-8t5z4vqa76rl/api-pLVzJnE6NKDL/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [
                {
                  inlineData: {
                    mimeType: mimeType,
                    data: base64Data,
                  },
                },
                {
                  text: prompt,
                },
              ],
            },
          ],
        }),
      }
    );

    if (!geminiResponse.ok) {
      const errorText = await geminiResponse.text();
      console.error('Gemini API error:', errorText);
      return new Response(
        JSON.stringify({ error: 'Failed to analyze food image', details: errorText }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const responseText = await geminiResponse.text();
    
    const lines = responseText.split('\n').filter(line => line.trim().startsWith('data:'));
    let fullText = '';
    
    for (const line of lines) {
      const jsonStr = line.replace('data:', '').trim();
      if (jsonStr) {
        try {
          const parsed = JSON.parse(jsonStr);
          if (parsed.candidates?.[0]?.content?.parts?.[0]?.text) {
            fullText += parsed.candidates[0].content.parts[0].text;
          }
        } catch (e) {
          console.error('Error parsing SSE line:', e);
        }
      }
    }

    const jsonMatch = fullText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      return new Response(
        JSON.stringify({ error: 'Could not extract JSON from AI response', rawResponse: fullText }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const analysisResult: FoodAnalysisResult = JSON.parse(jsonMatch[0]);

    return new Response(
      JSON.stringify({
        success: true,
        data: {
          foodName: analysisResult.foodName,
          calories: Math.round(analysisResult.calories),
          protein: Number(analysisResult.protein.toFixed(2)),
          carbohydrates: Number(analysisResult.carbohydrates.toFixed(2)),
          fats: Number(analysisResult.fats.toFixed(2)),
          portionSize: analysisResult.portionSize,
          confidence: Number(analysisResult.confidence.toFixed(2)),
        },
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in analyze-food function:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error', details: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
