-- Create food database table
CREATE TABLE public.food_database (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  image_url TEXT NOT NULL,
  calories INTEGER NOT NULL,
  protein DECIMAL(5,2) NOT NULL,
  carbohydrates DECIMAL(5,2) NOT NULL,
  fats DECIMAL(5,2) NOT NULL,
  serving_size TEXT NOT NULL,
  category TEXT NOT NULL,
  is_healthy BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Insert food items with nutrition data
INSERT INTO public.food_database (name, description, image_url, calories, protein, carbohydrates, fats, serving_size, category, is_healthy) VALUES
('Grilled Chicken Breast with Vegetables', 'Lean grilled chicken breast served with steamed mixed vegetables', 'https://miaoda-site-img.s3cdn.medo.dev/images/dbdbb7fa-655b-441e-97cf-e6c78c5feb78.jpg', 320, 42.0, 18.0, 8.0, '1 plate (250g)', 'Main Course', true),
('Brown Rice Bowl with Vegetables', 'Nutritious brown rice topped with colorful mixed vegetables', 'https://miaoda-site-img.s3cdn.medo.dev/images/0d10441b-5a05-4cc3-a2c4-4dd46bb9a7e9.jpg', 280, 8.0, 52.0, 4.0, '1 bowl (300g)', 'Main Course', true),
('Fresh Green Salad', 'Crisp mixed greens with fresh vegetables and light dressing', 'https://miaoda-site-img.s3cdn.medo.dev/images/631e34e9-f381-4aaf-8309-42ab38677b1b.jpg', 120, 3.0, 15.0, 5.0, '1 bowl (200g)', 'Salad', true),
('Whole Wheat Turkey Sandwich', 'Healthy sandwich with turkey breast, lettuce, and whole grain bread', 'https://miaoda-site-img.s3cdn.medo.dev/images/06c98404-fcff-4707-9fdd-6fd2f3af76b5.jpg', 350, 28.0, 42.0, 8.0, '1 sandwich', 'Main Course', true),
('Oatmeal Bowl with Fruits', 'Hearty oatmeal topped with fresh fruits and nuts', 'https://miaoda-site-img.s3cdn.medo.dev/images/18c92438-9d3a-41a5-9cda-950ab4c12c3b.jpg', 290, 10.0, 48.0, 8.0, '1 bowl (250g)', 'Breakfast', true),
('Greek Yogurt Parfait', 'Creamy Greek yogurt layered with berries and granola', 'https://miaoda-site-img.s3cdn.medo.dev/images/9843df7c-6f36-4cfe-b30f-beb3904269b3.jpg', 240, 15.0, 32.0, 6.0, '1 cup (200g)', 'Breakfast', true),
('Salmon with Broccoli and Quinoa', 'Grilled salmon fillet with steamed broccoli and quinoa', 'https://miaoda-site-img.s3cdn.medo.dev/images/1b075798-7f4a-41ea-bc3c-b70b2cffc6c1.jpg', 420, 38.0, 28.0, 18.0, '1 plate (300g)', 'Main Course', true),
('Vegetable Stir Fry with Tofu', 'Colorful vegetables stir-fried with protein-rich tofu', 'https://miaoda-site-img.s3cdn.medo.dev/images/9bc72637-5e90-4ec4-b02c-aaf097aa2606.jpg', 260, 16.0, 24.0, 12.0, '1 plate (280g)', 'Main Course', true),
('Fruit Smoothie Bowl', 'Refreshing smoothie bowl with banana, berries, and toppings', 'https://miaoda-site-img.s3cdn.medo.dev/images/9af1ee27-94da-43f4-8b29-fc56699cd2d6.jpg', 310, 8.0, 58.0, 6.0, '1 bowl (350g)', 'Breakfast', true),
('Avocado Toast', 'Whole grain toast topped with fresh avocado and seasonings', 'https://miaoda-site-img.s3cdn.medo.dev/images/660e67bd-af06-4471-914d-196da828986e.jpg', 280, 8.0, 32.0, 14.0, '2 slices', 'Breakfast', true),
('Scrambled Eggs with Vegetables', 'Fluffy scrambled eggs with spinach and tomatoes', 'https://miaoda-site-img.s3cdn.medo.dev/images/92ea56c5-f5a3-4fda-b2ec-1c7b2d124072.jpg', 220, 18.0, 8.0, 14.0, '1 plate (200g)', 'Breakfast', true),
('Lentil Vegetable Soup', 'Hearty soup with lentils and mixed vegetables', 'https://miaoda-site-img.s3cdn.medo.dev/images/d31128c4-3bf6-464f-8dd5-b2f89547d000.jpg', 210, 14.0, 32.0, 3.0, '1 bowl (300g)', 'Soup', true),
('Grilled Fish with Vegetables', 'Fresh grilled fish with steamed seasonal vegetables', 'https://miaoda-site-img.s3cdn.medo.dev/images/2cc0f210-e0b9-4fa9-a80d-b33a1ea47e2a.jpg', 290, 35.0, 12.0, 10.0, '1 plate (250g)', 'Main Course', true),
('Chicken Caesar Salad', 'Classic Caesar salad with grilled chicken breast', 'https://miaoda-site-img.s3cdn.medo.dev/images/2a636f60-eba4-4d23-952f-5eb3bc00f368.jpg', 380, 32.0, 18.0, 20.0, '1 bowl (300g)', 'Salad', true),
('Pasta with Tomato Sauce', 'Whole wheat pasta with fresh tomato and vegetable sauce', 'https://miaoda-site-img.s3cdn.medo.dev/images/5d8ef894-d6fb-4e2a-8154-3cdcd16dad94.jpg', 340, 12.0, 58.0, 6.0, '1 plate (280g)', 'Main Course', true);

-- Enable RLS
ALTER TABLE public.food_database ENABLE ROW LEVEL SECURITY;

-- Allow all authenticated users to view food database
CREATE POLICY "All authenticated users can view food database" ON food_database
  FOR SELECT TO authenticated USING (true);

-- Allow admins to manage food database
CREATE POLICY "Admins can manage food database" ON food_database
  FOR ALL TO authenticated USING (is_admin(auth.uid()));