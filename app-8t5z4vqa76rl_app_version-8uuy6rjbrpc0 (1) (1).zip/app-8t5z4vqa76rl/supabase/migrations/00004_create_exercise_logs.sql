-- Create exercise logs table
CREATE TABLE public.exercise_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  exercise_id UUID NOT NULL REFERENCES exercise_recommendations(id) ON DELETE CASCADE,
  duration_minutes INTEGER NOT NULL,
  calories_burned INTEGER NOT NULL,
  exercise_date DATE NOT NULL DEFAULT CURRENT_DATE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create index for faster queries
CREATE INDEX idx_exercise_logs_user_date ON exercise_logs(user_id, exercise_date DESC);
CREATE INDEX idx_exercise_logs_user_created ON exercise_logs(user_id, created_at DESC);

-- Enable RLS
ALTER TABLE public.exercise_logs ENABLE ROW LEVEL SECURITY;

-- Users can view their own exercise logs
CREATE POLICY "Users can view their own exercise logs" ON exercise_logs
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Users can insert their own exercise logs
CREATE POLICY "Users can insert their own exercise logs" ON exercise_logs
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- Users can update their own exercise logs
CREATE POLICY "Users can update their own exercise logs" ON exercise_logs
  FOR UPDATE TO authenticated USING (auth.uid() = user_id);

-- Users can delete their own exercise logs
CREATE POLICY "Users can delete their own exercise logs" ON exercise_logs
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Admins have full access
CREATE POLICY "Admins have full access to exercise logs" ON exercise_logs
  FOR ALL TO authenticated USING (is_admin(auth.uid()));