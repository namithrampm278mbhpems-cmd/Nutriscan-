-- Create user role enum
CREATE TYPE public.user_role AS ENUM ('user', 'admin');

-- Create gender enum
CREATE TYPE public.gender_type AS ENUM ('male', 'female', 'other');

-- Create activity level enum
CREATE TYPE public.activity_level AS ENUM ('sedentary', 'lightly_active', 'moderately_active', 'very_active', 'extremely_active');

-- Create fitness goal enum
CREATE TYPE public.fitness_goal AS ENUM ('weight_loss', 'fat_loss', 'muscle_gain', 'maintain_fitness');

-- Create profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT,
  username TEXT UNIQUE NOT NULL,
  role public.user_role NOT NULL DEFAULT 'user'::public.user_role,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create user_profiles table for health data
CREATE TABLE public.user_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  gender public.gender_type NOT NULL,
  age INTEGER NOT NULL CHECK (age > 0 AND age < 150),
  height DECIMAL(5,2) NOT NULL CHECK (height > 0),
  weight DECIMAL(5,2) NOT NULL CHECK (weight > 0),
  activity_level public.activity_level NOT NULL,
  fitness_goal public.fitness_goal NOT NULL,
  daily_calorie_target INTEGER NOT NULL,
  onboarding_completed BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id)
);

-- Create food_scans table
CREATE TABLE public.food_scans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  food_name TEXT NOT NULL,
  calories INTEGER NOT NULL,
  protein DECIMAL(5,2),
  carbohydrates DECIMAL(5,2),
  fats DECIMAL(5,2),
  portion_size TEXT,
  ai_confidence DECIMAL(3,2),
  scanned_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create daily_logs table
CREATE TABLE public.daily_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  log_date DATE NOT NULL,
  total_calories INTEGER NOT NULL DEFAULT 0,
  total_protein DECIMAL(5,2) NOT NULL DEFAULT 0,
  total_carbohydrates DECIMAL(5,2) NOT NULL DEFAULT 0,
  total_fats DECIMAL(5,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, log_date)
);

-- Create exercise_recommendations table
CREATE TABLE public.exercise_recommendations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  calories_per_30min INTEGER NOT NULL,
  category TEXT NOT NULL,
  difficulty TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Insert default exercise recommendations
INSERT INTO public.exercise_recommendations (name, description, calories_per_30min, category, difficulty) VALUES
('Walking', 'Moderate pace walking for general fitness', 120, 'Cardio', 'Easy'),
('Jogging', 'Light jogging for cardiovascular health', 240, 'Cardio', 'Medium'),
('Running', 'High-intensity running for fat burning', 360, 'Cardio', 'Hard'),
('Cycling', 'Outdoor or stationary bike cycling', 280, 'Cardio', 'Medium'),
('Swimming', 'Full-body swimming workout', 320, 'Cardio', 'Medium'),
('Jump Rope', 'High-intensity skipping exercise', 340, 'Cardio', 'Hard'),
('Yoga', 'Flexibility and mindfulness practice', 100, 'Flexibility', 'Easy'),
('Weight Training', 'Strength building with weights', 180, 'Strength', 'Medium'),
('HIIT', 'High-Intensity Interval Training', 400, 'Cardio', 'Hard'),
('Pilates', 'Core strengthening exercises', 140, 'Flexibility', 'Medium');

-- Create trigger function for user sync
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
BEGIN
  SELECT COUNT(*) INTO user_count FROM profiles;
  INSERT INTO public.profiles (id, email, username, role)
  VALUES (
    NEW.id,
    NEW.email,
    SPLIT_PART(NEW.email, '@', 1),
    CASE WHEN user_count = 0 THEN 'admin'::public.user_role ELSE 'user'::public.user_role END
  );
  RETURN NEW;
END;
$$;

-- Create trigger for user sync
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  WHEN (OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL)
  EXECUTE FUNCTION handle_new_user();

-- Create helper function for admin check
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.food_scans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exercise_recommendations ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Admins have full access to profiles" ON profiles
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can view their own profile" ON profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id)
  WITH CHECK (role IS NOT DISTINCT FROM (SELECT role FROM profiles WHERE id = auth.uid()));

-- User profiles policies
CREATE POLICY "Admins have full access to user_profiles" ON user_profiles
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can view their own user_profile" ON user_profiles
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own user_profile" ON user_profiles
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own user_profile" ON user_profiles
  FOR UPDATE TO authenticated USING (auth.uid() = user_id);

-- Food scans policies
CREATE POLICY "Users can view their own food_scans" ON food_scans
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own food_scans" ON food_scans
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own food_scans" ON food_scans
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Daily logs policies
CREATE POLICY "Users can view their own daily_logs" ON daily_logs
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own daily_logs" ON daily_logs
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own daily_logs" ON daily_logs
  FOR UPDATE TO authenticated USING (auth.uid() = user_id);

-- Exercise recommendations policies (read-only for all authenticated users)
CREATE POLICY "All authenticated users can view exercise_recommendations" ON exercise_recommendations
  FOR SELECT TO authenticated USING (true);

-- Create storage bucket for food images
INSERT INTO storage.buckets (id, name, public) VALUES ('app-8t5z4vqa76rl_food_images', 'app-8t5z4vqa76rl_food_images', true);

-- Storage policies for food images
CREATE POLICY "Authenticated users can upload food images" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'app-8t5z4vqa76rl_food_images');

CREATE POLICY "Public can view food images" ON storage.objects
  FOR SELECT TO public USING (bucket_id = 'app-8t5z4vqa76rl_food_images');

CREATE POLICY "Users can delete their own food images" ON storage.objects
  FOR DELETE TO authenticated USING (bucket_id = 'app-8t5z4vqa76rl_food_images' AND auth.uid()::text = (storage.foldername(name))[1]);