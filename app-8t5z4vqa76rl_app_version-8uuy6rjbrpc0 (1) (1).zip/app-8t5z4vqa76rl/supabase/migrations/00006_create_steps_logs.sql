-- Create steps logs table
CREATE TABLE public.steps_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  steps INTEGER NOT NULL CHECK (steps >= 0),
  calories_burned INTEGER NOT NULL,
  log_date DATE NOT NULL DEFAULT CURRENT_DATE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create unique constraint to allow only one entry per user per day
CREATE UNIQUE INDEX idx_steps_logs_user_date ON steps_logs(user_id, log_date);

-- Create index for faster queries
CREATE INDEX idx_steps_logs_user_created ON steps_logs(user_id, created_at DESC);

-- Enable RLS
ALTER TABLE public.steps_logs ENABLE ROW LEVEL SECURITY;

-- Users can view their own steps logs
CREATE POLICY "Users can view their own steps logs" ON steps_logs
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Users can insert their own steps logs
CREATE POLICY "Users can insert their own steps logs" ON steps_logs
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- Users can update their own steps logs
CREATE POLICY "Users can update their own steps logs" ON steps_logs
  FOR UPDATE TO authenticated USING (auth.uid() = user_id);

-- Users can delete their own steps logs
CREATE POLICY "Users can delete their own steps logs" ON steps_logs
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Admins have full access
CREATE POLICY "Admins have full access to steps logs" ON steps_logs
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_steps_logs_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to automatically update updated_at
CREATE TRIGGER steps_logs_updated_at
  BEFORE UPDATE ON steps_logs
  FOR EACH ROW
  EXECUTE FUNCTION update_steps_logs_updated_at();