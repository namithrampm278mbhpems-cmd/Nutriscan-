-- Insert South Indian breakfast items and nutritious foods
INSERT INTO public.food_database (name, description, image_url, calories, protein, carbohydrates, fats, serving_size, category, is_healthy) VALUES
-- South Indian Breakfast Items
('Medu Vada', 'Crispy deep-fried lentil donuts served with chutney and sambar', 'https://miaoda-site-img.s3cdn.medo.dev/images/a9c07a4a-49d7-42ba-b822-ccc2060d8252.jpg', 280, 8.0, 32.0, 14.0, '3 vadas', 'Breakfast', true),
('Uttapam', 'Thick savory pancake with onions, tomatoes, and vegetables', 'https://miaoda-site-img.s3cdn.medo.dev/images/915dd184-10c8-482c-bd06-a1598bce23e8.jpg', 240, 7.0, 42.0, 5.0, '1 uttapam (200g)', 'Breakfast', true),
('Pongal', 'Savory rice and lentil dish tempered with spices and ghee', 'https://miaoda-site-img.s3cdn.medo.dev/images/8cff0e83-c5a1-4027-b735-11c27e3cccf6.jpg', 260, 9.0, 45.0, 6.0, '1 bowl (250g)', 'Breakfast', true),
('Appam', 'Soft rice pancake with crispy edges served with coconut milk', 'https://miaoda-site-img.s3cdn.medo.dev/images/4c008209-9749-43f1-96a0-2a51dfd18ff1.jpg', 180, 4.0, 35.0, 3.0, '2 appams', 'Breakfast', true),
('Pesarattu', 'Green gram dosa packed with protein and nutrients', 'https://miaoda-site-img.s3cdn.medo.dev/images/7f047e5a-fe64-428c-a24e-244218ca0a0d.jpg', 200, 10.0, 32.0, 4.0, '1 dosa (180g)', 'Breakfast', true),

-- Nutritious Breakfast Items
('Quinoa Breakfast Bowl', 'Protein-rich quinoa with fresh fruits, nuts, and honey', 'https://miaoda-site-img.s3cdn.medo.dev/images/ad5dad55-d9d3-42f5-817a-80c8428f7fac.jpg', 320, 12.0, 52.0, 8.0, '1 bowl (300g)', 'Breakfast', true),
('Chia Seed Pudding', 'Chia seeds soaked in almond milk with berries and nuts', 'https://miaoda-site-img.s3cdn.medo.dev/images/350fcb57-e643-45d6-8391-88d55657352d.jpg', 240, 8.0, 28.0, 12.0, '1 cup (250g)', 'Breakfast', true),
('Greek Yogurt Berry Bowl', 'High-protein Greek yogurt with fresh berries and granola', 'https://miaoda-site-img.s3cdn.medo.dev/images/42ae736e-9105-4a32-82de-4f45464883c9.jpg', 280, 18.0, 38.0, 6.0, '1 bowl (300g)', 'Breakfast', true),
('Protein Smoothie Bowl', 'Blended protein smoothie topped with fruits, seeds, and nuts', 'https://miaoda-site-img.s3cdn.medo.dev/images/4fb30910-b6ae-4160-bf86-9956e16cee23.jpg', 340, 22.0, 42.0, 10.0, '1 bowl (350g)', 'Breakfast', true),
('Avocado Egg Toast', 'Whole grain toast with mashed avocado and poached eggs', 'https://miaoda-site-img.s3cdn.medo.dev/images/9770c75c-4567-46d3-9726-5c34eb6646b7.jpg', 360, 16.0, 32.0, 18.0, '2 slices', 'Breakfast', true),

-- Nutritious Main Course Items
('Grilled Salmon with Vegetables', 'Omega-3 rich salmon with roasted seasonal vegetables', 'https://miaoda-site-img.s3cdn.medo.dev/images/3192a129-0de5-41a3-900d-6ab834961783.jpg', 380, 42.0, 18.0, 16.0, '1 plate (280g)', 'Main Course', true),
('Chicken Breast Salad Bowl', 'Grilled chicken breast with mixed greens and vinaigrette', 'https://miaoda-site-img.s3cdn.medo.dev/images/c0b3ef1a-5e2f-475b-9687-f9c617eeda4a.jpg', 320, 38.0, 22.0, 10.0, '1 bowl (350g)', 'Main Course', true),
('Roasted Vegetables with Quinoa', 'Colorful roasted vegetables served over protein-rich quinoa', 'https://miaoda-site-img.s3cdn.medo.dev/images/9a07fc82-bd08-401c-9fa6-f2e6a9835d7f.jpg', 280, 10.0, 48.0, 6.0, '1 bowl (300g)', 'Main Course', true),
('Tuna Salad', 'Fresh tuna with mixed greens, tomatoes, and olive oil', 'https://miaoda-site-img.s3cdn.medo.dev/images/ceff7668-f44f-42a0-8e79-9eef3d73d982.jpg', 260, 32.0, 12.0, 10.0, '1 bowl (280g)', 'Salad', true),

-- Nutritious Soup
('Healthy Lentil Soup', 'Protein-packed lentil soup with vegetables and spices', 'https://miaoda-site-img.s3cdn.medo.dev/images/ee253906-00ca-4ba1-9767-d0148979d841.jpg', 220, 16.0, 34.0, 3.0, '1 bowl (300g)', 'Soup', true);