# Task: AI-Powered Calorie Tracking Device for Canteen Menu

## Plan
- [x] Step 1-16: Previous features (Design, Backend, Auth, Onboarding, Dashboard, Scanner, History, Exercises, Food Database, Charts, Widgets, Exercise Logging)
- [x] Step 17: Add South Indian Breakfast Items (5 items)
- [x] Step 18: Add Nutritious Superfoods (10 items)
- [x] Step 19: Add Calories Burned to History Page
- [x] Step 20: Add Step Tracking Feature
  - [x] Create steps_logs database table with RLS policies
  - [x] Add unique constraint for one entry per user per day
  - [x] Create stepsLogsApi with CRUD functions
  - [x] Add step tracking state to Exercises page
  - [x] Create "Log Steps" dialog with steps input and notes
  - [x] Implement automatic calorie calculation (0.04 cal/step)
  - [x] Add Steps Today widget to exercise stats (4th card)
  - [x] Display steps count and calories burned from steps
  - [x] Update Dashboard to include steps calories in total burned
  - [x] Update History page to include steps calories in charts and logs
  - [x] Add dual button interface (Log Steps + Log Exercise)
  - [x] Implement upsert logic for updating same-day steps
- [x] Step 21: Validation & Testing
  - [x] Run npm run lint and fix all issues
  - [x] Verify all features work end-to-end

## Notes
- Using Gemini API (plugin: 63a58b4a-6c16-4b03-9480-97d678a4238e) for AI food recognition
- Authentication: Username + password (simulated with @miaoda.com)
- No email verification needed (disabled via supabase_verification)
- Image upload: Supabase Storage with 1MB limit and auto-compression
- First registered user becomes admin automatically
- Food Database: 45 foods across 5 categories (Breakfast, Main Course, Salad, Soup, Snack)
- Indian Foods: 15 authentic dishes including Biryani, Dal Tadka, Paneer, Dosa, Idli, Samosa, etc.
- South Indian Breakfast: 5 items (Medu Vada, Uttapam, Pongal, Appam, Pesarattu)
- Nutritious Foods: 10 superfoods including quinoa, chia seeds, Greek yogurt, salmon, etc.
- History Page: Bar charts showing consumed, burned (exercises + steps), and net calories
- Dashboard: Beautiful widgets with 4 stat cards including steps and exercise calories
- Exercise Logging: Complete system for tracking workouts with calories burned calculation
- Step Tracking: Daily step logging with automatic calorie calculation (0.04 cal/step)
- Database: 8 tables including exercise_logs and steps_logs tables
- Calories Burned: Integrated from both exercises and steps throughout the app
- All features implemented successfully
- Lint passed with no errors
