import Login from './pages/Login';
import Register from './pages/Register';
import ProfileSetup from './pages/ProfileSetup';
import GoalSelection from './pages/GoalSelection';
import Dashboard from './pages/Dashboard';
import FoodScanner from './pages/FoodScanner';
import FoodDatabase from './pages/FoodDatabase';
import History from './pages/History';
import Exercises from './pages/Exercises';
import AppLayout from './components/layouts/AppLayout';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  layout?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Login',
    path: '/login',
    element: <Login />,
    visible: false,
  },
  {
    name: 'Register',
    path: '/register',
    element: <Register />,
    visible: false,
  },
  {
    name: 'Profile Setup',
    path: '/profile-setup',
    element: <ProfileSetup />,
    visible: false,
  },
  {
    name: 'Goal Selection',
    path: '/goal-selection',
    element: <GoalSelection />,
    visible: false,
  },
  {
    name: 'Dashboard',
    path: '/dashboard',
    element: <Dashboard />,
    layout: true,
  },
  {
    name: 'Food Scanner',
    path: '/scan',
    element: <FoodScanner />,
    layout: true,
  },
  {
    name: 'Food Database',
    path: '/foods',
    element: <FoodDatabase />,
    layout: true,
  },
  {
    name: 'History',
    path: '/history',
    element: <History />,
    layout: true,
  },
  {
    name: 'Exercises',
    path: '/exercises',
    element: <Exercises />,
    layout: true,
  },
];

export default routes;
