import { supabase } from '@/db/supabase';
import type {
  Profile,
  UserProfile,
  FoodScan,
  DailyLog,
  ExerciseRecommendation,
  FoodAnalysisResult,
  ActivityLevel,
  FitnessGoal,
  GenderType,
} from '@/types/database';

export const profilesApi = {
  async getCurrentProfile(): Promise<Profile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', (await supabase.auth.getUser()).data.user?.id || '')
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async updateProfile(id: string, updates: Partial<Profile>): Promise<Profile> {
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },
};

export const userProfilesApi = {
  async getUserProfile(userId: string): Promise<UserProfile | null> {
    const { data, error } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async createUserProfile(profile: {
    user_id: string;
    gender: GenderType;
    age: number;
    height: number;
    weight: number;
    activity_level: ActivityLevel;
    fitness_goal: FitnessGoal;
    daily_calorie_target: number;
  }): Promise<UserProfile> {
    const { data, error } = await supabase
      .from('user_profiles')
      .insert({
        ...profile,
        onboarding_completed: true,
      })
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async updateUserProfile(userId: string, updates: Partial<UserProfile>): Promise<UserProfile> {
    const { data, error } = await supabase
      .from('user_profiles')
      .update(updates)
      .eq('user_id', userId)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },
};

export const foodScansApi = {
  async createFoodScan(scan: {
    user_id: string;
    image_url: string;
    food_name: string;
    calories: number;
    protein?: number;
    carbohydrates?: number;
    fats?: number;
    portion_size?: string;
    ai_confidence?: number;
  }): Promise<FoodScan> {
    const { data, error } = await supabase
      .from('food_scans')
      .insert(scan)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async getUserFoodScans(userId: string, limit = 50): Promise<FoodScan[]> {
    const { data, error } = await supabase
      .from('food_scans')
      .select('*')
      .eq('user_id', userId)
      .order('scanned_at', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getTodayFoodScans(userId: string): Promise<FoodScan[]> {
    const today = new Date().toISOString().split('T')[0];
    const { data, error } = await supabase
      .from('food_scans')
      .select('*')
      .eq('user_id', userId)
      .gte('scanned_at', `${today}T00:00:00`)
      .lte('scanned_at', `${today}T23:59:59`)
      .order('scanned_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async deleteFoodScan(id: string): Promise<void> {
    const { error } = await supabase
      .from('food_scans')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },
};

export const dailyLogsApi = {
  async getDailyLog(userId: string, date: string): Promise<DailyLog | null> {
    const { data, error } = await supabase
      .from('daily_logs')
      .select('*')
      .eq('user_id', userId)
      .eq('log_date', date)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async upsertDailyLog(log: {
    user_id: string;
    log_date: string;
    total_calories: number;
    total_protein: number;
    total_carbohydrates: number;
    total_fats: number;
  }): Promise<DailyLog> {
    const { data, error } = await supabase
      .from('daily_logs')
      .upsert(log, { onConflict: 'user_id,log_date' })
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async getWeeklyLogs(userId: string, startDate: string, endDate: string): Promise<DailyLog[]> {
    const { data, error } = await supabase
      .from('daily_logs')
      .select('*')
      .eq('user_id', userId)
      .gte('log_date', startDate)
      .lte('log_date', endDate)
      .order('log_date', { ascending: true });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },
};

export const exerciseRecommendationsApi = {
  async getAllExercises(): Promise<ExerciseRecommendation[]> {
    const { data, error } = await supabase
      .from('exercise_recommendations')
      .select('*')
      .order('name', { ascending: true });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getExercisesByCategory(category: string): Promise<ExerciseRecommendation[]> {
    const { data, error } = await supabase
      .from('exercise_recommendations')
      .select('*')
      .eq('category', category)
      .order('name', { ascending: true });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },
};

export interface ExerciseLog {
  id: string;
  user_id: string;
  exercise_id: string;
  duration_minutes: number;
  calories_burned: number;
  exercise_date: string;
  notes: string | null;
  created_at: string;
  exercise_recommendations?: ExerciseRecommendation;
}

export const exerciseLogsApi = {
  async logExercise(
    userId: string,
    exerciseId: string,
    durationMinutes: number,
    caloriesBurned: number,
    exerciseDate: string,
    notes?: string
  ): Promise<ExerciseLog> {
    const { data, error } = await supabase
      .from('exercise_logs')
      .insert({
        user_id: userId,
        exercise_id: exerciseId,
        duration_minutes: durationMinutes,
        calories_burned: caloriesBurned,
        exercise_date: exerciseDate,
        notes: notes || null,
      })
      .select('*')
      .single();
    
    if (error) throw error;
    return data;
  },

  async getUserExerciseLogs(userId: string, limit: number = 30): Promise<ExerciseLog[]> {
    const { data, error } = await supabase
      .from('exercise_logs')
      .select(`
        *,
        exercise_recommendations (*)
      `)
      .eq('user_id', userId)
      .order('exercise_date', { ascending: false })
      .order('created_at', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getTodayExerciseLogs(userId: string): Promise<ExerciseLog[]> {
    const today = new Date().toISOString().split('T')[0];
    const { data, error } = await supabase
      .from('exercise_logs')
      .select(`
        *,
        exercise_recommendations (*)
      `)
      .eq('user_id', userId)
      .eq('exercise_date', today)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getWeeklyExerciseLogs(userId: string, startDate: string, endDate: string): Promise<ExerciseLog[]> {
    const { data, error } = await supabase
      .from('exercise_logs')
      .select(`
        *,
        exercise_recommendations (*)
      `)
      .eq('user_id', userId)
      .gte('exercise_date', startDate)
      .lte('exercise_date', endDate)
      .order('exercise_date', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async deleteExerciseLog(logId: string): Promise<void> {
    const { error } = await supabase
      .from('exercise_logs')
      .delete()
      .eq('id', logId);
    
    if (error) throw error;
  },

  async getTotalCaloriesBurned(userId: string, date: string): Promise<number> {
    const { data, error } = await supabase
      .from('exercise_logs')
      .select('calories_burned')
      .eq('user_id', userId)
      .eq('exercise_date', date);
    
    if (error) throw error;
    if (!Array.isArray(data)) return 0;
    
    return data.reduce((sum, log) => sum + log.calories_burned, 0);
  },
};

export interface StepsLog {
  id: string;
  user_id: string;
  steps: number;
  calories_burned: number;
  log_date: string;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export const stepsLogsApi = {
  async logSteps(
    userId: string,
    steps: number,
    caloriesBurned: number,
    logDate: string,
    notes?: string
  ): Promise<StepsLog> {
    const { data, error } = await supabase
      .from('steps_logs')
      .upsert({
        user_id: userId,
        steps: steps,
        calories_burned: caloriesBurned,
        log_date: logDate,
        notes: notes || null,
      }, {
        onConflict: 'user_id,log_date'
      })
      .select('*')
      .single();
    
    if (error) throw error;
    return data;
  },

  async getTodaySteps(userId: string): Promise<StepsLog | null> {
    const today = new Date().toISOString().split('T')[0];
    const { data, error } = await supabase
      .from('steps_logs')
      .select('*')
      .eq('user_id', userId)
      .eq('log_date', today)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async getUserStepsLogs(userId: string, limit: number = 30): Promise<StepsLog[]> {
    const { data, error } = await supabase
      .from('steps_logs')
      .select('*')
      .eq('user_id', userId)
      .order('log_date', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getWeeklyStepsLogs(userId: string, startDate: string, endDate: string): Promise<StepsLog[]> {
    const { data, error } = await supabase
      .from('steps_logs')
      .select('*')
      .eq('user_id', userId)
      .gte('log_date', startDate)
      .lte('log_date', endDate)
      .order('log_date', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async deleteStepsLog(logId: string): Promise<void> {
    const { error } = await supabase
      .from('steps_logs')
      .delete()
      .eq('id', logId);
    
    if (error) throw error;
  },

  async getTotalStepsCaloriesBurned(userId: string, date: string): Promise<number> {
    const { data, error } = await supabase
      .from('steps_logs')
      .select('calories_burned')
      .eq('user_id', userId)
      .eq('log_date', date)
      .maybeSingle();
    
    if (error) throw error;
    return data?.calories_burned || 0;
  },
};

export interface FoodDatabaseItem {
  id: string;
  name: string;
  description: string | null;
  image_url: string;
  calories: number;
  protein: number;
  carbohydrates: number;
  fats: number;
  serving_size: string;
  category: string;
  is_healthy: boolean;
  created_at: string;
}

export const foodDatabaseApi = {
  async getAllFoods(): Promise<FoodDatabaseItem[]> {
    const { data, error } = await supabase
      .from('food_database')
      .select('*')
      .order('name', { ascending: true });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getFoodsByCategory(category: string): Promise<FoodDatabaseItem[]> {
    const { data, error } = await supabase
      .from('food_database')
      .select('*')
      .eq('category', category)
      .order('name', { ascending: true });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async searchFoods(query: string): Promise<FoodDatabaseItem[]> {
    const { data, error } = await supabase
      .from('food_database')
      .select('*')
      .ilike('name', `%${query}%`)
      .order('name', { ascending: true })
      .limit(20);
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getFoodById(id: string): Promise<FoodDatabaseItem | null> {
    const { data, error } = await supabase
      .from('food_database')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },
};

export const aiApi = {
  async analyzeFoodImage(imageData: string, mimeType: string): Promise<FoodAnalysisResult> {
    const { data, error } = await supabase.functions.invoke('analyze-food', {
      body: JSON.stringify({
        imageData,
        mimeType,
      }),
    });

    if (error) {
      const errorMsg = await error?.context?.text();
      console.error('Edge function error in analyze-food:', errorMsg || error?.message);
      throw new Error(errorMsg || error?.message || 'Failed to analyze food image');
    }

    if (!data?.success) {
      throw new Error(data?.error || 'Failed to analyze food image');
    }

    return data.data;
  },
};

export const storageApi = {
  async uploadFoodImage(file: File, userId: string): Promise<string> {
    const fileExt = file.name.split('.').pop();
    const fileName = `${userId}/${Date.now()}.${fileExt}`;
    
    const { data, error } = await supabase.storage
      .from('app-8t5z4vqa76rl_food_images')
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: false,
      });

    if (error) throw error;

    const { data: { publicUrl } } = supabase.storage
      .from('app-8t5z4vqa76rl_food_images')
      .getPublicUrl(data.path);

    return publicUrl;
  },
};

export function calculateDailyCalorieTarget(
  gender: GenderType,
  age: number,
  height: number,
  weight: number,
  activityLevel: ActivityLevel,
  fitnessGoal: FitnessGoal
): number {
  let bmr: number;
  if (gender === 'male') {
    bmr = 10 * weight + 6.25 * height - 5 * age + 5;
  } else {
    bmr = 10 * weight + 6.25 * height - 5 * age - 161;
  }

  const activityMultipliers: Record<ActivityLevel, number> = {
    sedentary: 1.2,
    lightly_active: 1.375,
    moderately_active: 1.55,
    very_active: 1.725,
    extremely_active: 1.9,
  };

  const tdee = bmr * activityMultipliers[activityLevel];

  const goalAdjustments: Record<FitnessGoal, number> = {
    weight_loss: -500,
    fat_loss: -300,
    muscle_gain: 300,
    maintain_fitness: 0,
  };

  return Math.round(tdee + goalAdjustments[fitnessGoal]);
}
