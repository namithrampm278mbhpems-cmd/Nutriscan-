export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

export interface Profile {
  id: string;
  email: string | null;
  username: string;
  role: 'user' | 'admin';
  created_at: string;
  updated_at: string;
}
