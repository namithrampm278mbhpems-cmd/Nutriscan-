export type UserRole = 'user' | 'admin';
export type GenderType = 'male' | 'female' | 'other';
export type ActivityLevel = 'sedentary' | 'lightly_active' | 'moderately_active' | 'very_active' | 'extremely_active';
export type FitnessGoal = 'weight_loss' | 'fat_loss' | 'muscle_gain' | 'maintain_fitness';

export interface Profile {
  id: string;
  email: string | null;
  username: string;
  role: UserRole;
  created_at: string;
  updated_at: string;
}

export interface UserProfile {
  id: string;
  user_id: string;
  gender: GenderType;
  age: number;
  height: number;
  weight: number;
  activity_level: ActivityLevel;
  fitness_goal: FitnessGoal;
  daily_calorie_target: number;
  onboarding_completed: boolean;
  created_at: string;
  updated_at: string;
}

export interface FoodScan {
  id: string;
  user_id: string;
  image_url: string;
  food_name: string;
  calories: number;
  protein: number | null;
  carbohydrates: number | null;
  fats: number | null;
  portion_size: string | null;
  ai_confidence: number | null;
  scanned_at: string;
}

export interface DailyLog {
  id: string;
  user_id: string;
  log_date: string;
  total_calories: number;
  total_protein: number;
  total_carbohydrates: number;
  total_fats: number;
  created_at: string;
  updated_at: string;
}

export interface ExerciseRecommendation {
  id: string;
  name: string;
  description: string | null;
  calories_per_30min: number;
  category: string;
  difficulty: string;
  created_at: string;
}

export interface FoodAnalysisResult {
  foodName: string;
  calories: number;
  protein: number;
  carbohydrates: number;
  fats: number;
  portionSize: string;
  confidence: number;
}
