import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { Camera, TrendingUp, TrendingDown, Target, Flame, Activity, Zap, Award, Calendar } from 'lucide-react';
import { userProfilesApi, dailyLogsApi, exerciseLogsApi, stepsLogsApi } from '@/db/api';
import type { UserProfile, DailyLog } from '@/types/database';

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [todayLog, setTodayLog] = useState<DailyLog | null>(null);
  const [caloriesBurned, setCaloriesBurned] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const loadDashboardData = async () => {
      try {
        const userProfile = await userProfilesApi.getUserProfile(user.id);
        
        if (!userProfile || !userProfile.onboarding_completed) {
          navigate('/profile-setup');
          return;
        }

        setProfile(userProfile);

        const today = new Date().toISOString().split('T')[0];
        const log = await dailyLogsApi.getDailyLog(user.id, today);
        setTodayLog(log);

        const exerciseBurned = await exerciseLogsApi.getTotalCaloriesBurned(user.id, today);
        const stepsBurned = await stepsLogsApi.getTotalStepsCaloriesBurned(user.id, today);
        setCaloriesBurned(exerciseBurned + stepsBurned);
      } catch (error) {
        console.error('Error loading dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadDashboardData();
  }, [user, navigate]);

  if (loading) {
    return (
      <div className="p-4 xl:p-8 space-y-6">
        <Skeleton className="h-8 w-64 bg-muted" />
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          <Skeleton className="h-32 bg-muted" />
          <Skeleton className="h-32 bg-muted" />
          <Skeleton className="h-32 bg-muted" />
          <Skeleton className="h-32 bg-muted" />
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="p-4 xl:p-8">
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <p className="text-muted-foreground">Profile not found</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const caloriesConsumed = todayLog?.total_calories || 0;
  const caloriesRemaining = Math.max(0, profile.daily_calorie_target - caloriesConsumed);
  const netCalories = caloriesConsumed - caloriesBurned;
  const progressPercentage = Math.min(100, (caloriesConsumed / profile.daily_calorie_target) * 100);
  const isOverTarget = caloriesConsumed > profile.daily_calorie_target;

  return (
    <div className="p-4 xl:p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Track your daily nutrition and fitness goals</p>
        </div>
        <Link to="/scan">
          <Button size="lg" className="gap-2">
            <Camera className="h-5 w-5" />
            Scan Food
          </Button>
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {/* Calories Consumed */}
        <Card className="border-l-4 border-l-primary">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Flame className="h-4 w-4" />
              Calories Consumed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">{caloriesConsumed}</div>
            <p className="text-xs text-muted-foreground mt-1">
              of {profile.daily_calorie_target} kcal target
            </p>
          </CardContent>
        </Card>

        {/* Calories Burned */}
        <Card className="border-l-4 border-l-chart-1">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Zap className="h-4 w-4" />
              Calories Burned
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ color: 'hsl(var(--chart-1))' }}>
              {caloriesBurned}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              from exercises today
            </p>
          </CardContent>
        </Card>

        {/* Net Calories */}
        <Card className="border-l-4 border-l-chart-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Net Calories
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ color: 'hsl(var(--chart-2))' }}>
              {netCalories}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              consumed - burned
            </p>
          </CardContent>
        </Card>

        {/* Remaining Calories */}
        <Card className="border-l-4 border-l-chart-3">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Target className="h-4 w-4" />
              Remaining
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-3xl font-bold ${isOverTarget ? 'text-destructive' : ''}`} style={!isOverTarget ? { color: 'hsl(var(--chart-3))' } : {}}>
              {isOverTarget ? '+' : ''}{Math.abs(caloriesRemaining)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {isOverTarget ? 'over target' : 'kcal left today'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Progress Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Today's Progress
          </CardTitle>
          <CardDescription>Your calorie intake vs. target</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium">Calorie Target Progress</span>
              <span className="font-bold text-primary">{progressPercentage.toFixed(0)}%</span>
            </div>
            <Progress value={progressPercentage} className="h-3" />
          </div>
          
          <div className="grid grid-cols-3 gap-4 pt-4 border-t">
            <div className="text-center">
              <p className="text-2xl font-bold text-primary">{caloriesConsumed}</p>
              <p className="text-xs text-muted-foreground">Consumed</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold" style={{ color: 'hsl(var(--chart-1))' }}>{caloriesBurned}</p>
              <p className="text-xs text-muted-foreground">Burned</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold" style={{ color: 'hsl(var(--chart-3))' }}>{caloriesRemaining}</p>
              <p className="text-xs text-muted-foreground">Remaining</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Macronutrients & Goal */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Macronutrients */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Macronutrients
            </CardTitle>
            <CardDescription>Today's nutrition breakdown</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: 'hsl(var(--chart-1))' }}></div>
                  <span className="text-sm font-medium">Protein</span>
                </div>
                <span className="text-lg font-bold">{todayLog?.total_protein.toFixed(1) || 0}g</span>
              </div>
              <Progress value={(Number(todayLog?.total_protein || 0) / 150) * 100} className="h-2" />
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: 'hsl(var(--chart-2))' }}></div>
                  <span className="text-sm font-medium">Carbohydrates</span>
                </div>
                <span className="text-lg font-bold">{todayLog?.total_carbohydrates.toFixed(1) || 0}g</span>
              </div>
              <Progress value={(Number(todayLog?.total_carbohydrates || 0) / 300) * 100} className="h-2" />
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: 'hsl(var(--chart-3))' }}></div>
                  <span className="text-sm font-medium">Fats</span>
                </div>
                <span className="text-lg font-bold">{todayLog?.total_fats.toFixed(1) || 0}g</span>
              </div>
              <Progress value={(Number(todayLog?.total_fats || 0) / 70) * 100} className="h-2" />
            </div>
          </CardContent>
        </Card>

        {/* Fitness Goal */}
        <Card className="bg-gradient-to-br from-primary/10 to-primary/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5 text-primary" />
              Your Fitness Goal
            </CardTitle>
            <CardDescription>Stay focused on your target</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-primary/20 rounded-full">
                {profile.fitness_goal === 'weight_loss' && <TrendingDown className="h-8 w-8 text-primary" />}
                {profile.fitness_goal === 'fat_loss' && <Flame className="h-8 w-8 text-primary" />}
                {profile.fitness_goal === 'muscle_gain' && <TrendingUp className="h-8 w-8 text-primary" />}
                {profile.fitness_goal === 'maintain_fitness' && <Target className="h-8 w-8 text-primary" />}
              </div>
              <div>
                <h3 className="text-2xl font-bold capitalize">
                  {profile.fitness_goal.replace('_', ' ')}
                </h3>
                <p className="text-sm text-muted-foreground">Current goal</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-4 border-t">
              <div>
                <p className="text-sm text-muted-foreground">Daily Target</p>
                <p className="text-xl font-bold text-primary">{profile.daily_calorie_target} kcal</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Activity Level</p>
                <p className="text-xl font-bold capitalize">{profile.activity_level.replace('_', ' ')}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Quick Actions
          </CardTitle>
          <CardDescription>Track your nutrition and fitness</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link to="/scan" className="block">
              <Button variant="outline" className="w-full h-20 flex flex-col gap-2">
                <Camera className="h-6 w-6" />
                <span>Scan Food</span>
              </Button>
            </Link>
            <Link to="/exercises" className="block">
              <Button variant="outline" className="w-full h-20 flex flex-col gap-2">
                <Activity className="h-6 w-6" />
                <span>Log Exercise</span>
              </Button>
            </Link>
            <Link to="/history" className="block">
              <Button variant="outline" className="w-full h-20 flex flex-col gap-2">
                <TrendingUp className="h-6 w-6" />
                <span>View History</span>
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
