import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Camera, Upload, Loader2, CheckCircle2 } from 'lucide-react';
import { aiApi, storageApi, foodScansApi, dailyLogsApi } from '@/db/api';
import type { FoodAnalysisResult } from '@/types/database';

async function compressImage(file: File): Promise<File> {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        const maxDimension = 1080;
        if (width > height && width > maxDimension) {
          height = (height * maxDimension) / width;
          width = maxDimension;
        } else if (height > maxDimension) {
          width = (width * maxDimension) / height;
          height = maxDimension;
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);

        canvas.toBlob(
          (blob) => {
            if (blob) {
              const compressedFile = new File([blob], file.name.replace(/\.\w+$/, '.webp'), {
                type: 'image/webp',
              });
              resolve(compressedFile);
            } else {
              resolve(file);
            }
          },
          'image/webp',
          0.8
        );
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  });
}

export default function FoodScanner() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<FoodAnalysisResult | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError('Please select a valid image file');
      return;
    }

    setError('');
    setAnalysisResult(null);
    setSuccess(false);

    let processedFile = file;
    if (file.size > 1024 * 1024) {
      processedFile = await compressImage(file);
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setSelectedImage(event.target?.result as string);
    };
    reader.readAsDataURL(processedFile);
  };

  const handleAnalyze = async () => {
    if (!selectedImage || !user) return;

    setAnalyzing(true);
    setError('');

    try {
      const mimeType = selectedImage.split(';')[0].split(':')[1];
      const result = await aiApi.analyzeFoodImage(selectedImage, mimeType);
      setAnalysisResult(result);
    } catch (err) {
      console.error('Error analyzing food:', err);
      setError('Failed to analyze food image. Please try again with a clearer image.');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSave = async () => {
    if (!analysisResult || !selectedImage || !user) return;

    setSaving(true);
    setError('');

    try {
      const blob = await fetch(selectedImage).then((r) => r.blob());
      const file = new File([blob], `food_${Date.now()}.webp`, { type: 'image/webp' });

      const imageUrl = await storageApi.uploadFoodImage(file, user.id);

      await foodScansApi.createFoodScan({
        user_id: user.id,
        image_url: imageUrl,
        food_name: analysisResult.foodName,
        calories: analysisResult.calories,
        protein: analysisResult.protein,
        carbohydrates: analysisResult.carbohydrates,
        fats: analysisResult.fats,
        portion_size: analysisResult.portionSize,
        ai_confidence: analysisResult.confidence,
      });

      const today = new Date().toISOString().split('T')[0];
      const todayScans = await foodScansApi.getTodayFoodScans(user.id);
      
      const totals = todayScans.reduce(
        (acc, scan) => ({
          calories: acc.calories + scan.calories,
          protein: acc.protein + (scan.protein || 0),
          carbs: acc.carbs + (scan.carbohydrates || 0),
          fats: acc.fats + (scan.fats || 0),
        }),
        { calories: 0, protein: 0, carbs: 0, fats: 0 }
      );

      await dailyLogsApi.upsertDailyLog({
        user_id: user.id,
        log_date: today,
        total_calories: totals.calories,
        total_protein: totals.protein,
        total_carbohydrates: totals.carbs,
        total_fats: totals.fats,
      });

      setSuccess(true);
      setTimeout(() => {
        navigate('/dashboard');
      }, 2000);
    } catch (err) {
      console.error('Error saving food scan:', err);
      setError('Failed to save food scan. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-4 xl:p-8 space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold mb-2">AI Food Scanner</h1>
        <p className="text-muted-foreground">Scan your food to track calories and nutrition</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Upload Food Image</CardTitle>
          <CardDescription>Take a photo or upload an image of your food</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="bg-primary/10 border-primary">
              <CheckCircle2 className="h-4 w-4 text-primary" />
              <AlertDescription className="text-primary">
                Food scan saved successfully! Redirecting to dashboard...
              </AlertDescription>
            </Alert>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
          />

          {!selectedImage ? (
            <div className="border-2 border-dashed border-border rounded-lg p-12 text-center">
              <Camera className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground mb-4">No image selected</p>
              <Button onClick={() => fileInputRef.current?.click()}>
                <Upload className="h-4 w-4 mr-2" />
                Select Image
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="relative rounded-lg overflow-hidden border">
                <img src={selectedImage} alt="Selected food" className="w-full h-auto" />
              </div>

              {!analysisResult && !analyzing && (
                <div className="flex gap-2">
                  <Button onClick={handleAnalyze} className="flex-1">
                    <Camera className="h-4 w-4 mr-2" />
                    Analyze Food
                  </Button>
                  <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                    Change Image
                  </Button>
                </div>
              )}

              {analyzing && (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  <span className="ml-3 text-muted-foreground">Analyzing food image...</span>
                </div>
              )}

              {analysisResult && !analyzing && (
                <Card className="bg-accent">
                  <CardHeader>
                    <CardTitle className="text-lg">Analysis Results</CardTitle>
                    <CardDescription>
                      Confidence: {(analysisResult.confidence * 100).toFixed(0)}%
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Food Item</p>
                      <p className="text-xl font-bold">{analysisResult.foodName}</p>
                    </div>

                    <div>
                      <p className="text-sm text-muted-foreground">Portion Size</p>
                      <p className="text-lg font-semibold">{analysisResult.portionSize}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Calories</p>
                        <p className="text-2xl font-bold text-primary">{analysisResult.calories} kcal</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Protein</p>
                        <p className="text-xl font-semibold">{analysisResult.protein}g</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Carbohydrates</p>
                        <p className="text-xl font-semibold">{analysisResult.carbohydrates}g</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Fats</p>
                        <p className="text-xl font-semibold">{analysisResult.fats}g</p>
                      </div>
                    </div>

                    <div className="flex gap-2 pt-4">
                      <Button onClick={handleSave} className="flex-1" disabled={saving || success}>
                        {saving ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Saving...
                          </>
                        ) : success ? (
                          <>
                            <CheckCircle2 className="h-4 w-4 mr-2" />
                            Saved!
                          </>
                        ) : (
                          'Save to Log'
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setSelectedImage(null);
                          setAnalysisResult(null);
                        }}
                        disabled={saving || success}
                      >
                        Scan Another
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
