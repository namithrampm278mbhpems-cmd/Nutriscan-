import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar, TrendingUp, Flame } from 'lucide-react';
import { foodScansApi, dailyLogsApi, exerciseLogsApi, stepsLogsApi } from '@/db/api';
import type { FoodScan, DailyLog } from '@/types/database';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function History() {
  const { user } = useAuth();
  const [foodScans, setFoodScans] = useState<FoodScan[]>([]);
  const [weeklyLogs, setWeeklyLogs] = useState<DailyLog[]>([]);
  const [weeklyCaloriesBurned, setWeeklyCaloriesBurned] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const loadHistory = async () => {
      try {
        const scans = await foodScansApi.getUserFoodScans(user.id, 30);
        setFoodScans(scans);

        const today = new Date();
        const weekAgo = new Date(today);
        weekAgo.setDate(weekAgo.getDate() - 7);

        const logs = await dailyLogsApi.getWeeklyLogs(
          user.id,
          weekAgo.toISOString().split('T')[0],
          today.toISOString().split('T')[0]
        );
        setWeeklyLogs(logs);

        // Fetch calories burned for each day (exercises + steps)
        const caloriesBurnedMap: Record<string, number> = {};
        for (const log of logs) {
          const exerciseBurned = await exerciseLogsApi.getTotalCaloriesBurned(user.id, log.log_date);
          const stepsBurned = await stepsLogsApi.getTotalStepsCaloriesBurned(user.id, log.log_date);
          caloriesBurnedMap[log.log_date] = exerciseBurned + stepsBurned;
        }
        setWeeklyCaloriesBurned(caloriesBurnedMap);
      } catch (error) {
        console.error('Error loading history:', error);
      } finally {
        setLoading(false);
      }
    };

    loadHistory();
  }, [user]);

  if (loading) {
    return (
      <div className="p-4 xl:p-8 space-y-6">
        <Skeleton className="h-8 w-64 bg-muted" />
        <Skeleton className="h-96 bg-muted" />
      </div>
    );
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatChartDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
    });
  };

  const chartData = weeklyLogs.map((log) => ({
    date: formatChartDate(log.log_date),
    calories: log.total_calories,
    burned: weeklyCaloriesBurned[log.log_date] || 0,
    net: log.total_calories - (weeklyCaloriesBurned[log.log_date] || 0),
    protein: Number(log.total_protein.toFixed(1)),
    carbs: Number(log.total_carbohydrates.toFixed(1)),
    fats: Number(log.total_fats.toFixed(1)),
  }));

  return (
    <div className="p-4 xl:p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">History</h1>
        <p className="text-muted-foreground">View your food scans and calorie logs</p>
      </div>

      <Tabs defaultValue="charts" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="charts">Charts</TabsTrigger>
          <TabsTrigger value="scans">Food Scans</TabsTrigger>
          <TabsTrigger value="logs">Daily Logs</TabsTrigger>
        </TabsList>

        <TabsContent value="charts" className="space-y-4 mt-6">
          {weeklyLogs.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <TrendingUp className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No data available yet</p>
                <p className="text-sm text-muted-foreground">Start tracking your meals to see charts</p>
              </CardContent>
            </Card>
          ) : (
            <>
              <Card>
                <CardHeader>
                  <CardTitle>Daily Calorie Intake & Burn</CardTitle>
                  <CardDescription>Your calorie consumption and exercise burn over the past 7 days</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis dataKey="date" className="text-xs" />
                      <YAxis className="text-xs" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'hsl(var(--card))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px',
                        }}
                      />
                      <Legend />
                      <Bar dataKey="calories" fill="hsl(var(--primary))" name="Consumed (kcal)" radius={[8, 8, 0, 0]} />
                      <Bar dataKey="burned" fill="hsl(var(--chart-1))" name="Burned (kcal)" radius={[8, 8, 0, 0]} />
                      <Bar dataKey="net" fill="hsl(var(--chart-2))" name="Net (kcal)" radius={[8, 8, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Macronutrient Breakdown</CardTitle>
                  <CardDescription>Protein, carbohydrates, and fats over the past 7 days</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis dataKey="date" className="text-xs" />
                      <YAxis className="text-xs" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'hsl(var(--card))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px',
                        }}
                      />
                      <Legend />
                      <Bar dataKey="protein" fill="hsl(var(--chart-1))" name="Protein (g)" radius={[8, 8, 0, 0]} />
                      <Bar dataKey="carbs" fill="hsl(var(--chart-2))" name="Carbs (g)" radius={[8, 8, 0, 0]} />
                      <Bar dataKey="fats" fill="hsl(var(--chart-3))" name="Fats (g)" radius={[8, 8, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="bg-accent">
                <CardHeader>
                  <CardTitle className="text-lg">📊 Weekly Summary</CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Consumed</p>
                    <p className="text-2xl font-bold text-primary">
                      {weeklyLogs.reduce((sum, log) => sum + log.total_calories, 0)}
                    </p>
                    <p className="text-xs text-muted-foreground">kcal this week</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Total Burned</p>
                    <p className="text-2xl font-bold" style={{ color: 'hsl(var(--chart-1))' }}>
                      {Object.values(weeklyCaloriesBurned).reduce((sum, val) => sum + val, 0)}
                    </p>
                    <p className="text-xs text-muted-foreground">kcal from exercise</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Net Calories</p>
                    <p className="text-2xl font-bold" style={{ color: 'hsl(var(--chart-2))' }}>
                      {weeklyLogs.reduce((sum, log) => sum + log.total_calories, 0) - 
                       Object.values(weeklyCaloriesBurned).reduce((sum, val) => sum + val, 0)}
                    </p>
                    <p className="text-xs text-muted-foreground">consumed - burned</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Days Tracked</p>
                    <p className="text-2xl font-bold">{weeklyLogs.length}</p>
                    <p className="text-xs text-muted-foreground">out of 7 days</p>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        <TabsContent value="scans" className="space-y-4 mt-6">
          {foodScans.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No food scans yet</p>
                <p className="text-sm text-muted-foreground">Start scanning your meals to see them here</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {foodScans.map((scan) => (
                <Card key={scan.id}>
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg">{scan.food_name}</CardTitle>
                        <CardDescription>
                          {formatDate(scan.scanned_at)} at {formatTime(scan.scanned_at)}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {scan.image_url && (
                      <img
                        src={scan.image_url}
                        alt={scan.food_name}
                        className="w-full h-32 object-cover rounded-md"
                      />
                    )}
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <p className="text-muted-foreground">Calories</p>
                        <p className="font-semibold text-primary">{scan.calories} kcal</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Portion</p>
                        <p className="font-semibold">{scan.portion_size || 'N/A'}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Protein</p>
                        <p className="font-semibold">{scan.protein?.toFixed(1) || 0}g</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Carbs</p>
                        <p className="font-semibold">{scan.carbohydrates?.toFixed(1) || 0}g</p>
                      </div>
                    </div>
                    {scan.ai_confidence && (
                      <p className="text-xs text-muted-foreground">
                        AI Confidence: {(scan.ai_confidence * 100).toFixed(0)}%
                      </p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="logs" className="space-y-4 mt-6">
          {weeklyLogs.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <TrendingUp className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No daily logs yet</p>
                <p className="text-sm text-muted-foreground">Your daily calorie logs will appear here</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {weeklyLogs.map((log) => {
                const caloriesBurned = weeklyCaloriesBurned[log.log_date] || 0;
                const netCalories = log.total_calories - caloriesBurned;
                
                return (
                  <Card key={log.id}>
                    <CardHeader>
                      <CardTitle className="text-lg">{formatDate(log.log_date)}</CardTitle>
                      <CardDescription>Daily nutrition and exercise summary</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Consumed</p>
                          <p className="text-2xl font-bold text-primary">{log.total_calories}</p>
                          <p className="text-xs text-muted-foreground">kcal</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground flex items-center gap-1">
                            <Flame className="h-3 w-3" />
                            Burned
                          </p>
                          <p className="text-2xl font-bold" style={{ color: 'hsl(var(--chart-1))' }}>
                            {caloriesBurned}
                          </p>
                          <p className="text-xs text-muted-foreground">kcal</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Net</p>
                          <p className="text-2xl font-bold" style={{ color: 'hsl(var(--chart-2))' }}>
                            {netCalories}
                          </p>
                          <p className="text-xs text-muted-foreground">kcal</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Protein</p>
                          <p className="text-2xl font-bold">{log.total_protein.toFixed(1)}</p>
                          <p className="text-xs text-muted-foreground">grams</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Carbs</p>
                          <p className="text-2xl font-bold">{log.total_carbohydrates.toFixed(1)}</p>
                          <p className="text-xs text-muted-foreground">grams</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
