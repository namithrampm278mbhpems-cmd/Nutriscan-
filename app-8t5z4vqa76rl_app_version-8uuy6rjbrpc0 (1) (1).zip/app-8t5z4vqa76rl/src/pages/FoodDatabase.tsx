import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, Utensils, Flame, Beef, Wheat, Droplet } from 'lucide-react';
import { foodDatabaseApi, type FoodDatabaseItem } from '@/db/api';

export default function FoodDatabase() {
  const [foods, setFoods] = useState<FoodDatabaseItem[]>([]);
  const [filteredFoods, setFilteredFoods] = useState<FoodDatabaseItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  useEffect(() => {
    const loadFoods = async () => {
      try {
        const allFoods = await foodDatabaseApi.getAllFoods();
        setFoods(allFoods);
        setFilteredFoods(allFoods);
      } catch (error) {
        console.error('Error loading food database:', error);
      } finally {
        setLoading(false);
      }
    };

    loadFoods();
  }, []);

  useEffect(() => {
    let filtered = foods;

    if (selectedCategory !== 'all') {
      filtered = filtered.filter((food) => food.category === selectedCategory);
    }

    if (searchQuery.trim()) {
      filtered = filtered.filter((food) =>
        food.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    setFilteredFoods(filtered);
  }, [searchQuery, selectedCategory, foods]);

  if (loading) {
    return (
      <div className="p-4 xl:p-8 space-y-6">
        <Skeleton className="h-8 w-64 bg-muted" />
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          <Skeleton className="h-96 bg-muted" />
          <Skeleton className="h-96 bg-muted" />
          <Skeleton className="h-96 bg-muted" />
        </div>
      </div>
    );
  }

  const categories = ['all', ...Array.from(new Set(foods.map((f) => f.category)))];

  return (
    <div className="p-4 xl:p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Food Database</h1>
        <p className="text-muted-foreground">Browse healthy food options with nutrition information</p>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search for foods..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full">
        <TabsList className="grid w-full max-w-3xl grid-cols-5">
          {categories.map((category) => (
            <TabsTrigger key={category} value={category} className="capitalize">
              {category}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value={selectedCategory} className="mt-6">
          {filteredFoods.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Utensils className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No foods found</p>
                <p className="text-sm text-muted-foreground">Try adjusting your search or category</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredFoods.map((food) => (
                <Card key={food.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={food.image_url}
                      alt={food.name}
                      className="w-full h-full object-cover"
                    />
                    {food.is_healthy && (
                      <Badge className="absolute top-2 right-2 bg-primary">
                        Healthy
                      </Badge>
                    )}
                  </div>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg">{food.name}</CardTitle>
                        <CardDescription className="mt-1">{food.description}</CardDescription>
                      </div>
                    </div>
                    <Badge variant="outline" className="w-fit mt-2">
                      {food.category}
                    </Badge>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-accent rounded-lg">
                      <div className="flex items-center gap-2">
                        <Flame className="h-5 w-5 text-destructive" />
                        <span className="text-sm font-medium">Calories</span>
                      </div>
                      <span className="text-xl font-bold text-primary">{food.calories} kcal</span>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <Beef className="h-4 w-4 text-muted-foreground" />
                          <span>Protein</span>
                        </div>
                        <span className="font-semibold">{food.protein}g</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <Wheat className="h-4 w-4 text-muted-foreground" />
                          <span>Carbs</span>
                        </div>
                        <span className="font-semibold">{food.carbohydrates}g</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <Droplet className="h-4 w-4 text-muted-foreground" />
                          <span>Fats</span>
                        </div>
                        <span className="font-semibold">{food.fats}g</span>
                      </div>
                    </div>

                    <div className="pt-2 border-t">
                      <p className="text-xs text-muted-foreground">
                        Serving Size: <span className="font-medium">{food.serving_size}</span>
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <Card className="bg-accent">
        <CardHeader>
          <CardTitle className="text-lg">💡 Nutrition Tips</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p>• Choose foods rich in protein to support muscle growth and recovery</p>
          <p>• Include complex carbohydrates for sustained energy throughout the day</p>
          <p>• Healthy fats are essential for hormone production and nutrient absorption</p>
          <p>• Balance your meals with a variety of nutrients for optimal health</p>
        </CardContent>
      </Card>
    </div>
  );
}
