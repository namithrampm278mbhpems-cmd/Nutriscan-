import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Activity, TrendingDown, Flame, Dumbbell, Target } from 'lucide-react';
import { userProfilesApi, calculateDailyCalorieTarget } from '@/db/api';
import type { FitnessGoal } from '@/types/database';

const goals = [
  {
    value: 'weight_loss' as FitnessGoal,
    title: 'Weight Loss',
    description: 'Lose weight through calorie deficit',
    icon: TrendingDown,
    color: 'text-chart-2',
  },
  {
    value: 'fat_loss' as FitnessGoal,
    title: 'Fat Loss',
    description: 'Reduce body fat while maintaining muscle',
    icon: Flame,
    color: 'text-destructive',
  },
  {
    value: 'muscle_gain' as FitnessGoal,
    title: 'Muscle Gain',
    description: 'Build muscle mass with calorie surplus',
    icon: Dumbbell,
    color: 'text-primary',
  },
  {
    value: 'maintain_fitness' as FitnessGoal,
    title: 'Maintain Fitness',
    description: 'Stay healthy and maintain current weight',
    icon: Target,
    color: 'text-warning',
  },
];

export default function GoalSelection() {
  const [selectedGoal, setSelectedGoal] = useState<FitnessGoal | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async () => {
    if (!selectedGoal) {
      setError('Please select a fitness goal');
      return;
    }

    setError('');
    setLoading(true);

    try {
      const profileSetupData = sessionStorage.getItem('profileSetup');
      if (!profileSetupData || !user) {
        setError('Profile data not found. Please go back and complete the profile setup.');
        setLoading(false);
        return;
      }

      const profileData = JSON.parse(profileSetupData);
      
      const dailyCalorieTarget = calculateDailyCalorieTarget(
        profileData.gender,
        profileData.age,
        profileData.height,
        profileData.weight,
        profileData.activityLevel,
        selectedGoal
      );

      await userProfilesApi.createUserProfile({
        user_id: user.id,
        gender: profileData.gender,
        age: profileData.age,
        height: profileData.height,
        weight: profileData.weight,
        activity_level: profileData.activityLevel,
        fitness_goal: selectedGoal,
        daily_calorie_target: dailyCalorieTarget,
      });

      sessionStorage.removeItem('profileSetup');
      navigate('/dashboard', { replace: true });
    } catch (err) {
      console.error('Error creating user profile:', err);
      setError('Failed to save your profile. Please try again.');
      setLoading(false);
    }
  };

  if (!user) {
    navigate('/login');
    return null;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-background to-secondary/10 p-4">
      <Card className="w-full max-w-4xl">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-primary rounded-full">
              <Activity className="h-8 w-8 text-primary-foreground" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold">Choose Your Fitness Goal</CardTitle>
          <CardDescription>Select the goal that best matches your health objectives</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {goals.map((goal) => {
              const Icon = goal.icon;
              return (
                <button
                  key={goal.value}
                  type="button"
                  onClick={() => setSelectedGoal(goal.value)}
                  disabled={loading}
                  className={`p-6 rounded-lg border-2 transition-all text-left hover:shadow-md ${
                    selectedGoal === goal.value
                      ? 'border-primary bg-accent'
                      : 'border-border hover:border-primary/50'
                  }`}
                >
                  <div className="flex items-start space-x-4">
                    <div className={`p-3 rounded-full bg-accent ${goal.color}`}>
                      <Icon className="h-6 w-6" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg mb-1">{goal.title}</h3>
                      <p className="text-sm text-muted-foreground">{goal.description}</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          <Button
            onClick={handleSubmit}
            className="w-full"
            disabled={loading || !selectedGoal}
          >
            {loading ? 'Setting up your profile...' : 'Complete Setup'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
