import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dumbbell, Flame, Clock, Plus, Trash2, TrendingUp, Award, Calendar, Footprints } from 'lucide-react';
import { exerciseRecommendationsApi, exerciseLogsApi, stepsLogsApi, type ExerciseLog, type StepsLog } from '@/db/api';
import type { ExerciseRecommendation } from '@/types/database';
import { useToast } from '@/hooks/use-toast';

export default function Exercises() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [exercises, setExercises] = useState<ExerciseRecommendation[]>([]);
  const [exerciseLogs, setExerciseLogs] = useState<ExerciseLog[]>([]);
  const [todayLogs, setTodayLogs] = useState<ExerciseLog[]>([]);
  const [todaySteps, setTodaySteps] = useState<StepsLog | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isStepsDialogOpen, setIsStepsDialogOpen] = useState(false);
  
  // Form state
  const [selectedExercise, setSelectedExercise] = useState<string>('');
  const [duration, setDuration] = useState<string>('30');
  const [exerciseDate, setExerciseDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState<string>('');
  const [steps, setSteps] = useState<string>('');
  const [stepsNotes, setStepsNotes] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!user) return;

    const loadData = async () => {
      try {
        const allExercises = await exerciseRecommendationsApi.getAllExercises();
        setExercises(allExercises);

        const logs = await exerciseLogsApi.getUserExerciseLogs(user.id, 30);
        setExerciseLogs(logs);

        const today = await exerciseLogsApi.getTodayExerciseLogs(user.id);
        setTodayLogs(today);

        const stepsData = await stepsLogsApi.getTodaySteps(user.id);
        setTodaySteps(stepsData);
      } catch (error) {
        console.error('Error loading exercises:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [user]);

  const handleLogExercise = async () => {
    if (!user || !selectedExercise || !duration) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    const exercise = exercises.find((e) => e.id === selectedExercise);
    if (!exercise) return;

    const durationNum = parseInt(duration);
    const caloriesBurned = Math.round((exercise.calories_per_30min / 30) * durationNum);

    setSubmitting(true);
    try {
      await exerciseLogsApi.logExercise(
        user.id,
        selectedExercise,
        durationNum,
        caloriesBurned,
        exerciseDate,
        notes || undefined
      );

      toast({
        title: 'Success',
        description: `Logged ${exercise.name} - ${caloriesBurned} calories burned!`,
      });

      // Refresh data
      const logs = await exerciseLogsApi.getUserExerciseLogs(user.id, 30);
      setExerciseLogs(logs);

      const today = await exerciseLogsApi.getTodayExerciseLogs(user.id);
      setTodayLogs(today);

      // Reset form
      setSelectedExercise('');
      setDuration('30');
      setNotes('');
      setIsDialogOpen(false);
    } catch (error) {
      console.error('Error logging exercise:', error);
      toast({
        title: 'Error',
        description: 'Failed to log exercise. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteLog = async (logId: string) => {
    if (!user) return;

    try {
      await exerciseLogsApi.deleteExerciseLog(logId);
      
      toast({
        title: 'Success',
        description: 'Exercise log deleted successfully',
      });

      // Refresh data
      const logs = await exerciseLogsApi.getUserExerciseLogs(user.id, 30);
      setExerciseLogs(logs);

      const today = await exerciseLogsApi.getTodayExerciseLogs(user.id);
      setTodayLogs(today);
    } catch (error) {
      console.error('Error deleting log:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete exercise log',
        variant: 'destructive',
      });
    }
  };

  const handleLogSteps = async () => {
    if (!user || !steps) {
      toast({
        title: 'Missing Information',
        description: 'Please enter the number of steps',
        variant: 'destructive',
      });
      return;
    }

    const stepsNum = parseInt(steps);
    if (isNaN(stepsNum) || stepsNum < 0) {
      toast({
        title: 'Invalid Input',
        description: 'Please enter a valid number of steps',
        variant: 'destructive',
      });
      return;
    }

    setSubmitting(true);

    try {
      // Calculate calories burned: approximately 0.04 calories per step
      const caloriesBurned = Math.round(stepsNum * 0.04);
      const today = new Date().toISOString().split('T')[0];

      await stepsLogsApi.logSteps(user.id, stepsNum, caloriesBurned, today, stepsNotes);

      toast({
        title: 'Success',
        description: `Logged ${stepsNum.toLocaleString()} steps (${caloriesBurned} calories burned)`,
      });

      // Refresh steps data
      const stepsData = await stepsLogsApi.getTodaySteps(user.id);
      setTodaySteps(stepsData);

      // Reset form
      setSteps('');
      setStepsNotes('');
      setIsStepsDialogOpen(false);
    } catch (error) {
      console.error('Error logging steps:', error);
      toast({
        title: 'Error',
        description: 'Failed to log steps. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="p-4 xl:p-8 space-y-6">
        <Skeleton className="h-8 w-64 bg-muted" />
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          <Skeleton className="h-64 bg-muted" />
          <Skeleton className="h-64 bg-muted" />
          <Skeleton className="h-64 bg-muted" />
        </div>
      </div>
    );
  }

  const filteredExercises = selectedCategory === 'all'
    ? exercises
    : exercises.filter((ex) => ex.category === selectedCategory);

  const totalCaloriesBurned = todayLogs.reduce((sum, log) => sum + log.calories_burned, 0);
  const totalDuration = todayLogs.reduce((sum, log) => sum + log.duration_minutes, 0);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <div className="p-4 xl:p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Exercises</h1>
          <p className="text-muted-foreground">Track your workouts and burn calories</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isStepsDialogOpen} onOpenChange={setIsStepsDialogOpen}>
            <DialogTrigger asChild>
              <Button size="lg" variant="outline" className="gap-2">
                <Footprints className="h-5 w-5" />
                Log Steps
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Log Daily Steps</DialogTitle>
                <DialogDescription>Track your walking activity and calories burned</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="steps">Number of Steps *</Label>
                  <Input
                    id="steps"
                    type="number"
                    min="0"
                    placeholder="e.g., 10000"
                    value={steps}
                    onChange={(e) => setSteps(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Approximately 0.04 calories burned per step
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="steps-notes">Notes (Optional)</Label>
                  <Textarea
                    id="steps-notes"
                    placeholder="Add any notes about your walk..."
                    value={stepsNotes}
                    onChange={(e) => setStepsNotes(e.target.value)}
                    rows={3}
                  />
                </div>

                {steps && (
                  <div className="bg-accent p-3 rounded-lg">
                    <p className="text-sm font-medium">Estimated Calories Burned</p>
                    <p className="text-2xl font-bold text-primary">
                      {Math.round(parseInt(steps || '0') * 0.04)} kcal
                    </p>
                  </div>
                )}
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsStepsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleLogSteps} disabled={submitting}>
                  {submitting ? 'Logging...' : 'Log Steps'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button size="lg" className="gap-2">
                <Plus className="h-5 w-5" />
                Log Exercise
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Log Exercise</DialogTitle>
                <DialogDescription>Record your workout and track calories burned</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="exercise">Exercise *</Label>
                  <Select value={selectedExercise} onValueChange={setSelectedExercise}>
                    <SelectTrigger id="exercise">
                      <SelectValue placeholder="Select an exercise" />
                    </SelectTrigger>
                    <SelectContent>
                      {exercises.map((exercise) => (
                        <SelectItem key={exercise.id} value={exercise.id}>
                          {exercise.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (minutes) *</Label>
                  <Input
                    id="duration"
                    type="number"
                    min="1"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    placeholder="30"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="date">Date *</Label>
                  <Input
                    id="date"
                    type="date"
                    value={exerciseDate}
                    onChange={(e) => setExerciseDate(e.target.value)}
                    max={new Date().toISOString().split('T')[0]}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Notes (optional)</Label>
                  <Textarea
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="How did you feel? Any achievements?"
                    rows={3}
                  />
                </div>

                {selectedExercise && duration && (
                  <div className="p-4 bg-accent rounded-lg">
                    <p className="text-sm text-muted-foreground">Estimated calories burned:</p>
                    <p className="text-2xl font-bold text-primary">
                      {Math.round(
                        (exercises.find((e) => e.id === selectedExercise)?.calories_per_30min || 0) /
                          30 *
                          parseInt(duration || '0')
                      )}{' '}
                      kcal
                    </p>
                  </div>
                )}

                <Button onClick={handleLogExercise} disabled={submitting} className="w-full">
                  {submitting ? 'Logging...' : 'Log Exercise'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Today's Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-primary">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Flame className="h-4 w-4" />
              Calories Burned Today
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">{totalCaloriesBurned}</div>
            <p className="text-xs text-muted-foreground mt-1">kcal from {todayLogs.length} exercises</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-chart-1">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Total Duration
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ color: 'hsl(var(--chart-1))' }}>
              {totalDuration}
            </div>
            <p className="text-xs text-muted-foreground mt-1">minutes of exercise</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-chart-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Award className="h-4 w-4" />
              Workouts Completed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ color: 'hsl(var(--chart-2))' }}>
              {todayLogs.length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">exercises today</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-chart-3">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Footprints className="h-4 w-4" />
              Steps Today
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ color: 'hsl(var(--chart-3))' }}>
              {todaySteps ? todaySteps.steps.toLocaleString() : '0'}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {todaySteps ? `${todaySteps.calories_burned} kcal burned` : 'No steps logged'}
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="recommendations" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          <TabsTrigger value="history">My Logs</TabsTrigger>
        </TabsList>

        <TabsContent value="recommendations" className="space-y-4 mt-6">
          <div className="flex gap-2 flex-wrap">
            <Button
              variant={selectedCategory === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory('all')}
            >
              All
            </Button>
            <Button
              variant={selectedCategory === 'Cardio' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory('Cardio')}
            >
              Cardio
            </Button>
            <Button
              variant={selectedCategory === 'Strength' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory('Strength')}
            >
              Strength
            </Button>
            <Button
              variant={selectedCategory === 'Flexibility' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory('Flexibility')}
            >
              Flexibility
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredExercises.map((exercise) => (
              <Card key={exercise.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Dumbbell className="h-5 w-5 text-primary" />
                        {exercise.name}
                      </CardTitle>
                      <CardDescription className="mt-2">{exercise.description}</CardDescription>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <Badge variant="outline">{exercise.category}</Badge>
                    <Badge variant="secondary">{exercise.difficulty}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-accent rounded-lg">
                    <div className="flex items-center gap-2">
                      <Flame className="h-5 w-5 text-destructive" />
                      <span className="text-sm font-medium">Calories</span>
                    </div>
                    <span className="text-xl font-bold text-primary">
                      {exercise.calories_per_30min}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">per 30 minutes</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-4 mt-6">
          {exerciseLogs.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No exercise logs yet</p>
                <p className="text-sm text-muted-foreground">Start logging your workouts to see them here</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {exerciseLogs.map((log) => (
                <Card key={log.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg">
                          {log.exercise_recommendations?.name || 'Unknown Exercise'}
                        </CardTitle>
                        <CardDescription>{formatDate(log.exercise_date)}</CardDescription>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteLog(log.id)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Duration</p>
                        <p className="text-xl font-bold">{log.duration_minutes} min</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Calories Burned</p>
                        <p className="text-xl font-bold text-primary">{log.calories_burned} kcal</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Category</p>
                        <Badge variant="outline">{log.exercise_recommendations?.category}</Badge>
                      </div>
                    </div>
                    {log.notes && (
                      <div className="mt-4 p-3 bg-accent rounded-lg">
                        <p className="text-sm text-muted-foreground">Notes:</p>
                        <p className="text-sm mt-1">{log.notes}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
