# Food Database - Complete List

This document contains all 30 healthy food items pre-loaded in the CalorieTracker application with their complete nutrition information, including 15 authentic Indian dishes.

## Breakfast Foods (10 items)

### 1. Avocado Toast
- **Description**: Whole grain toast topped with fresh avocado and seasonings
- **Serving Size**: 2 slices
- **Calories**: 280 kcal
- **Protein**: 8g
- **Carbohydrates**: 32g
- **Fats**: 14g
- **Category**: Breakfast
- **Image**: ✅ Included

### 2. Fruit Smoothie Bowl
- **Description**: Refreshing smoothie bowl with banana, berries, and toppings
- **Serving Size**: 1 bowl (350g)
- **Calories**: 310 kcal
- **Protein**: 8g
- **Carbohydrates**: 58g
- **Fats**: 6g
- **Category**: Breakfast
- **Image**: ✅ Included

### 3. Greek Yogurt Parfait
- **Description**: Creamy Greek yogurt layered with berries and granola
- **Serving Size**: 1 cup (200g)
- **Calories**: 240 kcal
- **Protein**: 15g
- **Carbohydrates**: 32g
- **Fats**: 6g
- **Category**: Breakfast
- **Image**: ✅ Included

### 4. Oatmeal Bowl with Fruits
- **Description**: Hearty oatmeal topped with fresh fruits and nuts
- **Serving Size**: 1 bowl (250g)
- **Calories**: 290 kcal
- **Protein**: 10g
- **Carbohydrates**: 48g
- **Fats**: 8g
- **Category**: Breakfast
- **Image**: ✅ Included

### 5. Scrambled Eggs with Vegetables
- **Description**: Fluffy scrambled eggs with spinach and tomatoes
- **Serving Size**: 1 plate (200g)
- **Calories**: 220 kcal
- **Protein**: 18g
- **Carbohydrates**: 8g
- **Fats**: 14g
- **Category**: Breakfast
- **Image**: ✅ Included

### 6. Masala Dosa 🇮🇳
- **Description**: Crispy rice crepe filled with spiced potato filling
- **Serving Size**: 1 dosa (200g)
- **Calories**: 320 kcal
- **Protein**: 8g
- **Carbohydrates**: 52g
- **Fats**: 8g
- **Category**: Breakfast
- **Image**: ✅ Included

### 7. Idli Sambar 🇮🇳
- **Description**: Steamed rice cakes served with lentil vegetable stew
- **Serving Size**: 3 idlis with sambar
- **Calories**: 220 kcal
- **Protein**: 8g
- **Carbohydrates**: 42g
- **Fats**: 2g
- **Category**: Breakfast
- **Image**: ✅ Included

### 8. Aloo Paratha 🇮🇳
- **Description**: Whole wheat flatbread stuffed with spiced potato filling
- **Serving Size**: 2 parathas
- **Calories**: 340 kcal
- **Protein**: 8g
- **Carbohydrates**: 48g
- **Fats**: 12g
- **Category**: Breakfast
- **Image**: ✅ Included

### 9. Upma 🇮🇳
- **Description**: Savory semolina porridge with vegetables and spices
- **Serving Size**: 1 bowl (200g)
- **Calories**: 200 kcal
- **Protein**: 6g
- **Carbohydrates**: 36g
- **Fats**: 4g
- **Category**: Breakfast
- **Image**: ✅ Included

### 10. Poha 🇮🇳
- **Description**: Flattened rice cooked with onions, peanuts, and spices
- **Serving Size**: 1 bowl (200g)
- **Calories**: 250 kcal
- **Protein**: 6g
- **Carbohydrates**: 42g
- **Fats**: 6g
- **Category**: Breakfast
- **Image**: ✅ Included

## Main Course Foods (16 items)

### 11. Grilled Chicken Breast with Vegetables
- **Description**: Lean grilled chicken breast served with steamed mixed vegetables
- **Serving Size**: 1 plate (250g)
- **Calories**: 320 kcal
- **Protein**: 42g
- **Carbohydrates**: 18g
- **Fats**: 8g
- **Category**: Main Course
- **Image**: ✅ Included

### 12. Brown Rice Bowl with Vegetables
- **Description**: Nutritious brown rice topped with colorful mixed vegetables
- **Serving Size**: 1 bowl (300g)
- **Calories**: 280 kcal
- **Protein**: 8g
- **Carbohydrates**: 52g
- **Fats**: 4g
- **Category**: Main Course
- **Image**: ✅ Included

### 13. Whole Wheat Turkey Sandwich
- **Description**: Healthy sandwich with turkey breast, lettuce, and whole grain bread
- **Serving Size**: 1 sandwich
- **Calories**: 350 kcal
- **Protein**: 28g
- **Carbohydrates**: 42g
- **Fats**: 8g
- **Category**: Main Course
- **Image**: ✅ Included

### 14. Salmon with Broccoli and Quinoa
- **Description**: Grilled salmon fillet with steamed broccoli and quinoa
- **Serving Size**: 1 plate (300g)
- **Calories**: 420 kcal
- **Protein**: 38g
- **Carbohydrates**: 28g
- **Fats**: 18g
- **Category**: Main Course
- **Image**: ✅ Included

### 15. Vegetable Stir Fry with Tofu
- **Description**: Colorful vegetables stir-fried with protein-rich tofu
- **Serving Size**: 1 plate (280g)
- **Calories**: 260 kcal
- **Protein**: 16g
- **Carbohydrates**: 24g
- **Fats**: 12g
- **Category**: Main Course
- **Image**: ✅ Included

### 16. Grilled Fish with Vegetables
- **Description**: Fresh grilled fish with steamed seasonal vegetables
- **Serving Size**: 1 plate (250g)
- **Calories**: 290 kcal
- **Protein**: 35g
- **Carbohydrates**: 12g
- **Fats**: 10g
- **Category**: Main Course
- **Image**: ✅ Included

### 17. Pasta with Tomato Sauce
- **Description**: Whole wheat pasta with fresh tomato and vegetable sauce
- **Serving Size**: 1 plate (280g)
- **Calories**: 340 kcal
- **Protein**: 12g
- **Carbohydrates**: 58g
- **Fats**: 6g
- **Category**: Main Course
- **Image**: ✅ Included

### 18. Chicken Biryani 🇮🇳
- **Description**: Aromatic basmati rice cooked with spiced chicken and herbs
- **Serving Size**: 1 plate (300g)
- **Calories**: 450 kcal
- **Protein**: 28g
- **Carbohydrates**: 58g
- **Fats**: 14g
- **Category**: Main Course
- **Image**: ✅ Included

### 19. Dal Tadka 🇮🇳
- **Description**: Yellow lentils tempered with spices and ghee
- **Serving Size**: 1 bowl (250g)
- **Calories**: 180 kcal
- **Protein**: 12g
- **Carbohydrates**: 28g
- **Fats**: 4g
- **Category**: Main Course
- **Image**: ✅ Included

### 20. Paneer Tikka Masala 🇮🇳
- **Description**: Cottage cheese cubes in rich creamy tomato gravy
- **Serving Size**: 1 bowl (280g)
- **Calories**: 380 kcal
- **Protein**: 18g
- **Carbohydrates**: 22g
- **Fats**: 24g
- **Category**: Main Course
- **Image**: ✅ Included

### 21. Butter Chicken with Naan 🇮🇳
- **Description**: Creamy tomato-based chicken curry served with naan bread
- **Serving Size**: 1 plate (350g)
- **Calories**: 520 kcal
- **Protein**: 32g
- **Carbohydrates**: 48g
- **Fats**: 22g
- **Category**: Main Course
- **Image**: ✅ Included

### 22. Chole Bhature 🇮🇳
- **Description**: Spicy chickpea curry with deep-fried bread
- **Serving Size**: 1 plate (300g)
- **Calories**: 480 kcal
- **Protein**: 14g
- **Carbohydrates**: 62g
- **Fats**: 18g
- **Category**: Main Course
- **Image**: ✅ Included

### 23. Palak Paneer 🇮🇳
- **Description**: Cottage cheese cubes in creamy spinach gravy
- **Serving Size**: 1 bowl (250g)
- **Calories**: 280 kcal
- **Protein**: 16g
- **Carbohydrates**: 18g
- **Fats**: 16g
- **Category**: Main Course
- **Image**: ✅ Included

### 24. Tandoori Chicken 🇮🇳
- **Description**: Yogurt-marinated chicken grilled in tandoor oven
- **Serving Size**: 1 plate (250g)
- **Calories**: 260 kcal
- **Protein**: 38g
- **Carbohydrates**: 8g
- **Fats**: 8g
- **Category**: Main Course
- **Image**: ✅ Included

### 25. Vegetable Pulao 🇮🇳
- **Description**: Fragrant basmati rice cooked with mixed vegetables and spices
- **Serving Size**: 1 bowl (280g)
- **Calories**: 300 kcal
- **Protein**: 8g
- **Carbohydrates**: 56g
- **Fats**: 6g
- **Category**: Main Course
- **Image**: ✅ Included

### 26. Rajma Curry 🇮🇳
- **Description**: Red kidney beans cooked in thick tomato-onion gravy
- **Serving Size**: 1 bowl (250g)
- **Calories**: 240 kcal
- **Protein**: 14g
- **Carbohydrates**: 38g
- **Fats**: 4g
- **Category**: Main Course
- **Image**: ✅ Included

## Salad Foods (2 items)

### 27. Fresh Green Salad
- **Description**: Crisp mixed greens with fresh vegetables and light dressing
- **Serving Size**: 1 bowl (200g)
- **Calories**: 120 kcal
- **Protein**: 3g
- **Carbohydrates**: 15g
- **Fats**: 5g
- **Category**: Salad
- **Image**: ✅ Included

### 28. Chicken Caesar Salad
- **Description**: Classic Caesar salad with grilled chicken breast
- **Serving Size**: 1 bowl (300g)
- **Calories**: 380 kcal
- **Protein**: 32g
- **Carbohydrates**: 18g
- **Fats**: 20g
- **Category**: Salad
- **Image**: ✅ Included

## Soup Foods (1 item)

### 29. Lentil Vegetable Soup
- **Description**: Hearty soup with lentils and mixed vegetables
- **Serving Size**: 1 bowl (300g)
- **Calories**: 210 kcal
- **Protein**: 14g
- **Carbohydrates**: 32g
- **Fats**: 3g
- **Category**: Soup
- **Image**: ✅ Included

## Snack Foods (1 item)

### 30. Samosa 🇮🇳
- **Description**: Crispy fried pastry filled with spiced potatoes and peas
- **Serving Size**: 2 pieces
- **Calories**: 260 kcal
- **Protein**: 6g
- **Carbohydrates**: 32g
- **Fats**: 12g
- **Category**: Snack
- **Image**: ✅ Included

## Nutrition Summary

### By Category
- **Breakfast**: 10 foods (Average: 257 kcal per serving)
- **Main Course**: 16 foods (Average: 329 kcal per serving)
- **Salad**: 2 foods (Average: 250 kcal per serving)
- **Soup**: 1 food (210 kcal per serving)
- **Snack**: 1 food (260 kcal per serving)

### Indian Food Highlights 🇮🇳
- **Total Indian Dishes**: 15 items
- **Breakfast Options**: 5 (Masala Dosa, Idli Sambar, Aloo Paratha, Upma, Poha)
- **Main Course Options**: 9 (Biryani, Dal Tadka, Paneer dishes, Butter Chicken, Chole Bhature, Tandoori Chicken, Vegetable Pulao, Rajma)
- **Snack Options**: 1 (Samosa)
- **Calorie Range**: 180-520 kcal
- **Protein-Rich Options**: Tandoori Chicken (38g), Butter Chicken (32g)
- **Low-Calorie Options**: Dal Tadka (180kcal), Upma (200kcal), Idli Sambar (220kcal)

### Calorie Range
- **Lowest**: Fresh Green Salad (120 kcal)
- **Highest**: Butter Chicken with Naan (520 kcal)
- **Average**: 295 kcal per serving

### Protein Content
- **Highest Protein**: Grilled Chicken Breast with Vegetables (42g)
- **Lowest Protein**: Fresh Green Salad (3g)
- **Average**: 15g per serving

### Healthy Options
- ✅ 28 out of 30 foods marked as healthy options
- ✅ Balanced macronutrient profiles
- ✅ Whole food ingredients
- ✅ Suitable for various fitness goals
- ⚠️ 2 indulgent options (Chole Bhature, Samosa) - enjoy in moderation

## Usage in Application

### Food Database Page
Users can:
1. Browse all foods by category
2. Search for specific foods by name
3. View detailed nutrition information
4. See beautiful food images
5. Use as reference for meal planning

### Benefits
- **Meal Inspiration**: Get ideas for healthy meals
- **Nutrition Education**: Learn about balanced nutrition
- **Calorie Awareness**: Understand calorie content of common foods
- **Goal Alignment**: Choose foods that match fitness goals

## Future Expansion

The food database can be easily expanded by:
1. Adding more food items to the database
2. Including regional/local cuisine options
3. Adding user-favorite foods
4. Creating custom meal combinations
5. Adding seasonal food recommendations

---

**Note**: All nutrition values are approximate and based on standard serving sizes. Actual values may vary based on preparation methods and specific ingredients used.
