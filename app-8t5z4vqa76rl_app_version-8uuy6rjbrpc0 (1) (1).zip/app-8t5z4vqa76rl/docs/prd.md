# AI-Powered Calorie Tracking Device for Canteen Menu Requirements Document

## 1. Application Overview

### 1.1 Application Name\nAI-Powered Calorie Tracking Device for Canteen Menu

### 1.2 Application Description
An innovative AI-driven health monitoring application designed for college students to track their daily calorie intake through intelligent food scanning. The application provides personalized fitness recommendations and exercise suggestions based on user profiles and fitness goals. Available on both Android and Web platforms, it addresses the real-world problem of unhealthy eating habits in college canteens through accurate AI-powered food recognition and calorie estimation.\n
### 1.3 Target Users
College students with no coding background who want to monitor their health and fitness through accurate calorie tracking.

## 2. Core Features

### 2.1 Authentication System\n- Login and Registration page as the first screen
- Email and Password authentication
- Simple and secure onboarding flow

### 2.2 Initial User Profile Setup (First-Time Use Only)\nAfter successful login, new users must complete a one-time profile setup including:
- Gender
- Age
- Height
- Weight
- Daily activity level\n
### 2.3 Fitness Goal & Physique Selection
Users select their fitness objective from the following options:
- Weight Loss
- Fat Loss
- Muscle Gain
- Maintain Fitness

Note: This setup is displayed only during first use. After completion, the app opens directly to the main dashboard.

### 2.4 Main Dashboard
The regular app home page displays:
- AI-Based Food Scanner access
- Daily calorie intake summary
- Remaining calories for the day
- Personalized exercise and fat-burn suggestions
- Beautiful and innovative widgets including:
  - Calorie intake progress widget with circular progress indicator
  - Quick stats widget showing calories consumed vs. remaining
  - Exercise summary widget displaying total calories burned today\n  - Water intake tracker widget\n  - Step counter widget showing steps completed today
  - Weekly progress overview widget with mini charts

### 2.5 AI-Based Accurate Food Scanner (Core Innovation)\nThe application includes a high-accuracy food scanner using Artificial Intelligence:
- Utilizes computer vision and machine learning models for food analysis
- Users scan food items from college canteen menu or food plate using camera
- AI system accurately identifies:
  - Food item name
  - Portion size (approximate)
  - Calorie count
  - Macronutrients (proteins, carbohydrates, fats)
- Scanned food data automatically updates daily calorie intake\n- Prioritizes accuracy for reliable calorie estimation suitable for health tracking\n\n### 2.6 Food Database with Nutrition Information
The application includes a comprehensive food database displaying:\n- Food images with visual reference\n- Detailed nutrition intake information for each food item including:
  - Calories per serving
  - Protein content
  - Carbohydrates content
  - Fat content
  - Fiber content
  - Other relevant micronutrients
- Common food items from college canteen menus
- Expanded Indian food items including:
  - Traditional Indian dishes: Biryani, Pulao, Dal Tadka, Rajma, Chole, Paneer Butter Masala, Palak Paneer, Aloo Gobi, Sambar, Rasam
  - Indian breads: Roti, Chapati, Naan, Paratha, Puri, Bhatura
  - Rice dishes: Jeera Rice, Lemon Rice, Curd Rice, Tamarind Rice\n  - Snacks: Samosa, Pakora, Vada, Dhokla, Kachori, Bhel Puri, Pani Puri
  - South Indian items: Idli, Dosa, Uttapam, Medu Vada, Upma, Pongal
  - South Indian breakfast items: Rava Idli, Set Dosa, Masala Dosa, Onion Uttapam, Rava Upma, Vermicelli Upma, Pesarattu, Appam, Puttu, Idiyappam
  - Sweets: Gulab Jamun, Jalebi, Ladoo, Barfi, Kheer, Halwa\n  - Beverages: Lassi, Buttermilk, Masala Chai
- Nutritious food items including:\n  - Oats, Quinoa, Brown Rice, Whole Wheat Bread
  - Greek Yogurt, Cottage Cheese, Paneer
  - Boiled Eggs, Egg White Omelette
  - Fresh Fruits: Apple, Banana, Orange, Papaya, Watermelon, Pomegranate
  - Dry Fruits: Almonds, Walnuts, Cashews, Dates, Raisins
  - Vegetables: Spinach, Broccoli, Carrot, Beetroot, Cucumber, Tomato
  - Sprouts: Moong Sprouts, Chickpea Sprouts, Mixed Sprouts
  - Salads: Green Salad, Fruit Salad, Sprout Salad
  - Smoothies: Protein Smoothie, Fruit Smoothie, Green Smoothie
  - Soups: Vegetable Soup, Chicken Soup, Lentil Soup
- Users can browse and search food items to view nutrition details

### 2.7 Daily Calorie Monitoring
- Display total calories consumed per day
- Show recommended calorie limit based on user profile and fitness goal
- Visual progress bar indicating calorie consumption status

### 2.8 Exercise Logging and Tracking Interface
The application includes a dedicated exercise logging interface where users can:
- Manually enter exercises they have completed
- Select from common exercise types:
  - Walking
  - Jogging
  - Running
  - Cycling
  - Skipping
  - Yoga
  - Gym workouts (strength training, cardio)
  - Swimming
  - Sports activities
- Input exercise duration in minutes
- Input exercise intensity level (low, moderate, high)
- **Step Counter and Walking Calorie Calculator:**
  - Users can manually add the number of steps completed today
  - System automatically calculates calories burned from walking based on:
    - Number of steps entered
    - User profile (weight, age, gender)
    - Average step length and walking pace
  - Calculated walking calories are automatically added to total calories burned
  - Display current step count and corresponding calories burned
- System automatically calculates and displays calories burned based on:
  - Exercise type\n  - Duration
  - Intensity
  - User profile (weight, age, gender)
- View total calories burned for the day
- Exercise history log showing past workouts
- Visual widgets displaying:
  - Today's total calories burned
  - Weekly exercise summary
  - Exercise streak counter\n  - Calories burned vs. calories consumed comparison

### 2.9 Exercise & Fat Burn Recommendations
- Suggest exercises based on calorie intake and fitness goal
- Exercise examples: walking, jogging, cycling, skipping, yoga, gym workouts\n- Display estimated calories burned for each activity
- Personalized recommendations based on user's remaining calorie balance

### 2.10 History Page with Bar Graph Visualization
- Display daily and weekly calorie intake history
- Display daily and weekly calories burned history
- Bar graph visualization showing:
  - Daily calorie consumption over time\n  - Daily calories burned over time
  - Comparison with recommended calorie limit
  - Visual trends for easy tracking
- Interactive graph allowing users to view specific day details
- Historical data for monitoring progress
- Toggle option to switch between calorie intake view and calories burned view

### 2.11 Web Application Version
The web application provides:
- User profile overview
- Daily and weekly calorie history with bar graph visualization
- Daily and weekly calories burned history with bar graph visualization
- AI food scan records
- Exercise logging interface with calorie burn calculator
- Step counter input with walking calorie calculation
- Exercise recommendations dashboard
- Food database with nutrition information including expanded Indian food items and nutritious food options
- Beautiful dashboard widgets for enhanced user experience

## 3. Technical Requirements

### 3.1 Platform Support
- Android application
- Web application

### 3.2 AI Technology
- Computer vision for food image analysis\n- Machine learning models for accurate food recognition
- High-accuracy calorie and macronutrient estimation

### 3.3 User Interface
- Modern and professional design
- User-friendly interface suitable for non-technical users
- Intuitive navigation and workflow
- Clear display of food images and nutrition data
- Interactive bar graph charts for calorie history visualization
- Beautiful and innovative widget designs for dashboard and exercise tracking
- Visually appealing exercise logging interface
- Real-time calorie burn calculations and display
- Step counter input interface with instant calorie calculation feedback

## 4. College Project Focus

### 4.1 Academic Value\n- Emphasis on AI-powered accurate food analysis
- Solves real-world problem of unhealthy eating in college canteens\n- Easy to explain architecture and workflow for viva
- Suitable for academic evaluation, demo, and presentation

### 4.2 Innovation Highlights
- AI-driven food recognition system
- Personalized health monitoring solution\n- Practical application addressing student health concerns
- Demonstrates integration of artificial intelligence in health technology
- Comprehensive food database with visual and nutritional information including diverse Indian cuisine and nutritious food options
- Data visualization through interactive bar graphs for better user insights
- Innovative dashboard widgets for enhanced user engagement
- Interactive exercise logging with real-time calorie burn tracking
- Step-based walking calorie calculation integrated into exercise tracking
- Comprehensive history tracking for both calorie intake and calories burned